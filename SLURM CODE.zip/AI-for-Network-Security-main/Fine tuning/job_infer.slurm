#!/bin/bash
# ============================================================================
# SLURM job: inference only -- against 'none' (plain base model) or an
# adapter that has already finished fine-tuning.
#
# SUBMIT WITH:   sbatch job_infer.slurm none true
#           or:  sbatch job_infer.slurm model_weights_unibonn_full false
#           or:  sbatch job_infer.slurm model_weights_unibonn_half true my_run.json my-label
# MONITOR WITH:  squeue --me   and   tail -f infer_<jobid>.log
# ============================================================================
#SBATCH --job-name=ub_infer
#SBATCH --partition=sgpu_long
#SBATCH --account=ag_ifi_martini
#SBATCH --gpus=1
#SBATCH --time=4:00:00
#SBATCH --output=infer_%j.log
#SBATCH --error=infer_%j.log

set -euo pipefail
export SLURM_EXPORT_ENV=ALL

ADAPTER="${1:?Usage: sbatch job_infer.slurm <adapter_dir|none> <true|false> [output_path] [label]}"
TRUNCATE="${2:?Usage: sbatch job_infer.slurm <adapter_dir|none> <true|false> [output_path] [label]}"
OUTPUT_PATH="${3:-}"
LABEL="${4:-}"

echo "Job $SLURM_JOBID starting on $(hostname) at $(date)"
echo ">>> Adapter: $ADAPTER   Truncate: $TRUNCATE"

module load Miniforge3
ENV_DIR="$HOME/envs/refinement"
ENV_PY="$ENV_DIR/bin/python"
source activate "$ENV_DIR"

export HF_HUB_DISABLE_XET=1
export HF_HOME="${TMPDIR:-/tmp}/hf_cache_$SLURM_JOBID"
mkdir -p "$HF_HOME"

echo ">>> Preflight checks"
test -x "$ENV_PY" || { echo "ERROR: env Python not found"; exit 1; }
"$ENV_PY" -c "import torch, transformers, peft, accelerate, safetensors, bitsandbytes" \
    || { echo "ERROR: env missing packages"; exit 1; }
test -f test_unibonn_tiers_with_remediation.json || { echo "ERROR: missing test data"; exit 1; }
if [[ "$ADAPTER" != "none" ]]; then
    test -d "$ADAPTER" || { echo "ERROR: adapter dir not found: $ADAPTER"; exit 1; }
fi
test -f unibonn_pipeline.py || { echo "ERROR: missing unibonn_pipeline.py"; exit 1; }
test -f run_infer.py        || { echo "ERROR: missing run_infer.py"; exit 1; }

echo ">>> Preflight OK"
nvidia-smi

ARGS=(--adapter "$ADAPTER" --truncate "$TRUNCATE")
[[ -n "$OUTPUT_PATH" ]] && ARGS+=(--output_path "$OUTPUT_PATH")
[[ -n "$LABEL" ]] && ARGS+=(--label "$LABEL")

echo ">>> Running run_infer.py ${ARGS[*]} ..."
"$ENV_PY" run_infer.py "${ARGS[@]}"

echo "Job $SLURM_JOBID finished at $(date)"
