#!/bin/bash
# ============================================================================
# SLURM job: full UniBonn-Mini pipeline -- baseline inference, fine-tuning,
# and post-finetune inference, for BOTH the full-log and half-log truncation
# conditions. Produces four results_*.json files and two adapters.
#
# SUBMIT WITH:   sbatch job_pipeline.slurm
# MONITOR WITH:  squeue --me   and   tail -f pipeline_<jobid>.log
# ============================================================================
#SBATCH --job-name=ub_pipeline
#SBATCH --partition=sgpu_long
#SBATCH --account=ag_ifi_martini
#SBATCH --gpus=1
#SBATCH --mem=90G
#SBATCH --time=24:00:00
#SBATCH --output=pipeline_%j.log
#SBATCH --error=pipeline_%j.log

set -euo pipefail
export SLURM_EXPORT_ENV=ALL

echo "Job $SLURM_JOBID starting on $(hostname) at $(date)"

module load Miniforge3
ENV_DIR="$HOME/envs/refinement"
ENV_PY="$ENV_DIR/bin/python"
source activate "$ENV_DIR"

export HF_HUB_DISABLE_XET=1
export HF_HOME="${TMPDIR:-/tmp}/hf_cache_$SLURM_JOBID"
mkdir -p "$HF_HOME"
echo ">>> HF cache for this job: $HF_HOME"
echo ">>> This job downloads the base model fresh -- first run will be slow"
echo ">>> (~28GB download); subsequent runs in the same HF_HOME are cached."

echo ">>> Preflight checks"
test -x "$ENV_PY" || { echo "ERROR: env Python not found"; exit 1; }
"$ENV_PY" -c "import torch, transformers, peft, accelerate, safetensors, bitsandbytes" \
    || { echo "ERROR: env missing packages (bitsandbytes is required for 4-bit)"; exit 1; }
test -f train_unibonn_tiers_with_remediation.json || { echo "ERROR: missing train_unibonn_tiers_with_remediation.json"; exit 1; }
test -f test_unibonn_tiers_with_remediation.json  || { echo "ERROR: missing test_unibonn_tiers_with_remediation.json"; exit 1; }
test -f unibonn_pipeline.py  || { echo "ERROR: missing unibonn_pipeline.py"; exit 1; }
test -f run_finetune.py      || { echo "ERROR: missing run_finetune.py"; exit 1; }
test -f run_infer.py         || { echo "ERROR: missing run_infer.py"; exit 1; }
test -f run_pipeline.py      || { echo "ERROR: missing run_pipeline.py"; exit 1; }

echo ">>> Preflight OK"
nvidia-smi

echo ">>> Running run_pipeline.py (baseline + finetune + infer, full and half) ..."
"$ENV_PY" run_pipeline.py

echo ">>> Scoring full-log condition"
"$ENV_PY" evaluate_unibonn.py results_baseline_full.json results_finetuned_full.json || true

echo ">>> Scoring half-log condition"
"$ENV_PY" evaluate_unibonn.py results_baseline_half.json results_finetuned_half.json || true

echo "Job $SLURM_JOBID finished at $(date)"
