"""
evaluate_unibonn.py — scores one or more result files from run_infer.py /
run_pipeline.py.

Adapted from the original six-attack evaluator for the new dataset:
    - ATTACK_TYPES dropped DNS_Spoofing, MITM (four attacks + None)
    - ground truth read from record["ground_truth"] as written by
      unibonn_pipeline.run_inference (attack_type, attacker_ip, victim_ip,
      reasoning, remediation, remediation_zone)
    - remediation is free text, not a fixed action/commands schema, so it is
      scored by SIMILARITY (difflib) against the reference remediation_text,
      plus two cheap structural checks: does the remediation escalate
      appropriately for a critical-zone incident, and does it name the
      attacker IP the model itself identified.

Metrics
-------
classification      attack_type accuracy, macro-F1, per-class P/R/F1,
                     confusion matrix, attack-vs-benign split
entity extraction    attacker_ip / victim_ip exact match
output health        parse errors, repaired JSON, keyword fallback,
                     response length, </think> repetition
grounding            every number/IP the model states is checked against
                     BOTH the telemetry AND the network reference block
                     (MAC table, host ports) — citing the reference table
                     correctly is not a hallucination, it is the point of
                     giving the model that block in the first place.
remediation          similarity to the reference plan, critical-zone
                     escalation-language check, and whether commands/steps
                     name the identified attacker.

Usage:
    python evaluate_unibonn.py results_baseline_full.json results_finetuned_full.json
    python evaluate_unibonn.py results_baseline_half.json results_finetuned_half.json
    python evaluate_unibonn.py results_finetuned_full.json results_finetuned_half.json
    python evaluate_unibonn.py results_finetuned_full.json   # single file
"""

import json
import re
import sys
import difflib
from collections import Counter, defaultdict

import unibonn_pipeline as P

ATTACK_TYPES = ["SYN_Flood", "ICMP_Flood", "ARP_Spoofing", "Port_Scan", "None"]

IP_RE  = re.compile(r"\b\d{1,3}(?:\.\d{1,3}){3}\b")
NUM_RE = re.compile(r"\b\d[\d,]{1,}\b")
DERIVED_OK = re.compile(r"(pps|pkt/s|packets per second|Gbit|Mbit|kbit|/24|per second)")

CRITICAL_LANGUAGE = re.compile(
    r"(MAJOR INCIDENT|change-control|security team lead|leadership sign-off)",
    re.IGNORECASE,
)

# every IP/MAC/port literal that appears in the fixed network reference block
# is always "grounded" — the model is supposed to be able to cite these.
_REFERENCE_NUMS = {n.replace(",", "") for n in NUM_RE.findall(P.NETWORK_REFERENCE_BLOCK)}
_REFERENCE_IPS  = set(IP_RE.findall(P.NETWORK_REFERENCE_BLOCK))


def _norm(s):
    return s.strip() if isinstance(s, str) else s


# --------------------------------------------------------------------------- #
# Grounding
# --------------------------------------------------------------------------- #

def grounding_score(record):
    """
    Fraction of numbers/IPs in the model's reasoning that are supported by
    either (a) this sample's own telemetry or (b) the fixed network reference
    block it was given. Returns (exact, derived, total, unsupported[:5]).
    """
    tel = " ".join(record.get("telemetry", {}).values())
    tel_nums = {n.replace(",", "") for n in NUM_RE.findall(tel)} | _REFERENCE_NUMS
    tel_ips = set(IP_RE.findall(tel)) | _REFERENCE_IPS

    raw = record.get("raw", "")
    think = raw.split("</think>")[0] if "</think>" in raw else ""
    p = record.get("parsed", {}) or {}
    reasoning = p.get("reasoning") or ""
    remediation = p.get("remediation") or ""
    said = f"{think}\n{reasoning}\n{remediation}".strip() or raw

    said_clean = re.sub(r"/\d{1,2}\b", "", said)  # strip CIDR suffixes

    exact = derived = total = 0
    bad = []
    for ip in set(IP_RE.findall(said_clean)):
        if ip.endswith(".0.0") or ip.endswith(".0"):
            continue
        total += 1
        if ip in tel_ips:
            exact += 1
        else:
            bad.append(ip)
    for m in NUM_RE.finditer(said_clean):
        n = m.group().replace(",", "")
        if len(n) < 2:
            continue
        total += 1
        if n in tel_nums:
            exact += 1
            continue
        ctx = said_clean[max(0, m.start() - 40): m.end() + 40]
        if DERIVED_OK.search(ctx):
            derived += 1
        else:
            bad.append(n)
    return exact, derived, total, sorted(set(bad))[:5]


# --------------------------------------------------------------------------- #
# Remediation similarity
# --------------------------------------------------------------------------- #

def remediation_score(record):
    """
    Returns (similarity_ratio, escalation_ok, names_attacker, is_benign).

    similarity_ratio  — difflib.SequenceMatcher ratio between the model's
                         remediation text and the reference remediation_text.
                         Not a great metric on its own (rewards verbatim
                         copying over correct-but-differently-worded plans),
                         which is why it is reported ALONGSIDE, not instead
                         of, the structural checks below.
    escalation_ok      — for critical-zone ground truth, does the model's
                         remediation contain critical-zone language? Always
                         True for non-critical ground truth (nothing to check).
    names_attacker      — if the model identified an attacker_ip, does its own
                         remediation text mention that IP? (a plan that never
                         names the host it should act on is not actionable)
    is_benign           — ground truth is "None"; remediation should be the
                         fixed one-line "no remediation required" plan.
    """
    gt = record["ground_truth"]
    p = record.get("parsed", {}) or {}

    ref_text = gt.get("remediation", "") or ""
    pred_text = p.get("remediation", "") or ""

    ratio = difflib.SequenceMatcher(None, ref_text, pred_text).ratio()

    is_benign = gt["attack_type"] == "None"
    if is_benign:
        escalation_ok = True  # nothing to escalate
    elif gt.get("remediation_zone") == "critical":
        escalation_ok = bool(CRITICAL_LANGUAGE.search(pred_text))
    else:
        escalation_ok = True  # no escalation required, can't fail this check

    pred_attacker = p.get("attacker_ip")
    names_attacker = (not is_benign and bool(pred_attacker)
                      and pred_attacker in pred_text)

    return ratio, escalation_ok, names_attacker, is_benign


# --------------------------------------------------------------------------- #
# Per-file scoring
# --------------------------------------------------------------------------- #

def score_file(path):
    data = json.load(open(path, encoding="utf-8"))
    recs = data["records"]
    label = data.get("model", path)
    truncated = data.get("truncated", None)

    y_true, y_pred = [], []
    parse_err = repaired = keyword = 0
    atk_ip_hits = atk_ip_total = 0
    vic_ip_hits = 0
    g_exact = g_derived = g_total = 0
    per_sample_ground = []
    unsupported_examples = []
    resp_lens, think_loops = [], 0

    rem_ratios = []
    escalation_hits = escalation_total = 0
    names_attacker_hits = names_attacker_total = 0
    benign_silent_hits = benign_total = 0

    for r in recs:
        gt = r["ground_truth"]
        p = r.get("parsed", {}) or {}
        y_true.append(gt["attack_type"])
        y_pred.append(p.get("attack_type", "None"))

        if p.get("_parse_error"): parse_err += 1
        if p.get("_repaired"):    repaired += 1
        if p.get("_keyword"):     keyword += 1

        raw = r.get("raw", "")
        resp_lens.append(len(raw.split()))
        if raw.count("</think>") > 1:
            think_loops += 1

        if gt["attack_type"] != "None":
            atk_ip_total += 1
            if _norm(p.get("attacker_ip")) == _norm(gt.get("attacker_ip")):
                atk_ip_hits += 1
        if _norm(p.get("victim_ip")) == _norm(gt.get("victim_ip")):
            vic_ip_hits += 1

        e, dv, t, bad = grounding_score(r)
        g_exact += e; g_derived += dv; g_total += t
        if t:
            per_sample_ground.append((e + dv) / t)
            if bad:
                unsupported_examples.append((r["id"], bad))

        ratio, esc_ok, names_atk, is_benign = remediation_score(r)
        rem_ratios.append(ratio)
        if gt.get("remediation_zone") == "critical" and not is_benign:
            escalation_total += 1
            escalation_hits += int(esc_ok)
        if not is_benign:
            names_attacker_total += 1
            names_attacker_hits += int(names_atk)
        if is_benign:
            benign_total += 1
            pred_rem = (p.get("remediation") or "").lower()
            benign_silent_hits += int(
                "no remediation required" in pred_rem
                or p.get("attack_type") == "None")

    n = len(recs)
    acc = sum(a == b for a, b in zip(y_true, y_pred)) / n

    per_class = {}
    f1s = []
    for c in ATTACK_TYPES:
        tp = sum(1 for a, b in zip(y_true, y_pred) if a == c and b == c)
        fp = sum(1 for a, b in zip(y_true, y_pred) if a != c and b == c)
        fn = sum(1 for a, b in zip(y_true, y_pred) if a == c and b != c)
        sup = sum(1 for a in y_true if a == c)
        if sup == 0:
            continue
        prec = tp / (tp + fp) if tp + fp else 0.0
        rec = tp / (tp + fn) if tp + fn else 0.0
        f1 = 2 * prec * rec / (prec + rec) if prec + rec else 0.0
        per_class[c] = {"precision": prec, "recall": rec, "f1": f1, "support": sup}
        f1s.append(f1)
    macro_f1 = sum(f1s) / len(f1s) if f1s else 0.0

    bt = [a != "None" for a in y_true]
    bp = [b != "None" for b in y_pred]
    bin_acc = sum(a == b for a, b in zip(bt, bp)) / n
    benign_recall = (sum(1 for a, b in zip(bt, bp) if not a and not b) /
                     max(1, sum(1 for a in bt if not a)))
    attack_recall = (sum(1 for a, b in zip(bt, bp) if a and b) /
                     max(1, sum(1 for a in bt if a)))

    conf = defaultdict(Counter)
    for a, b in zip(y_true, y_pred):
        conf[a][b] += 1

    return {
        "label": label, "n": n, "truncated": truncated,
        "accuracy": acc, "macro_f1": macro_f1,
        "per_class": per_class,
        "confusion": {k: dict(v) for k, v in conf.items()},
        "binary_accuracy": bin_acc,
        "attack_recall": attack_recall,
        "benign_recall": benign_recall,
        "attacker_ip_acc": atk_ip_hits / max(1, atk_ip_total),
        "victim_ip_acc": vic_ip_hits / n,
        "parse_errors": parse_err, "repaired": repaired, "keyword_only": keyword,
        "mean_response_words": sum(resp_lens) // max(1, len(resp_lens)),
        "think_loops": think_loops,
        "grounding_strict": g_exact / max(1, g_total),
        "grounding_lenient": (g_exact + g_derived) / max(1, g_total),
        "grounding_derived_forgiven": g_derived,
        "grounding_values_checked": g_total,
        "grounding_sample_mean": (sum(per_sample_ground) /
                                  max(1, len(per_sample_ground))),
        "unsupported_examples": unsupported_examples[:8],
        "remediation_similarity": sum(rem_ratios) / max(1, len(rem_ratios)),
        "remediation_escalation_ok": escalation_hits / max(1, escalation_total),
        "remediation_escalation_n": escalation_total,
        "remediation_names_attacker": (names_attacker_hits /
                                       max(1, names_attacker_total)),
        "remediation_benign_silent": benign_silent_hits / max(1, benign_total),
    }


# --------------------------------------------------------------------------- #
# Display
# --------------------------------------------------------------------------- #

def show(s):
    trunc_note = f"  [truncate={s['truncated']}]" if s["truncated"] is not None else ""
    print(f"\n{'='*70}\n{s['label']}   (n={s['n']}){trunc_note}\n{'='*70}")
    print("CLASSIFICATION")
    print(f"  attack_type accuracy   : {s['accuracy']:.3f}")
    print(f"  macro F1               : {s['macro_f1']:.3f}")
    print(f"  binary attack/benign   : {s['binary_accuracy']:.3f}")
    print(f"    attack recall        : {s['attack_recall']:.3f}")
    print(f"    benign recall        : {s['benign_recall']:.3f}   <- low = over-alerting")
    print("  per class:")
    for c, m in s["per_class"].items():
        print(f"    {c:<14} P={m['precision']:.2f} R={m['recall']:.2f} "
              f"F1={m['f1']:.2f}  (n={m['support']})")

    print("\nENTITIES")
    print(f"  attacker_ip exact      : {s['attacker_ip_acc']:.3f}")
    print(f"  victim_ip exact        : {s['victim_ip_acc']:.3f}")

    print("\nOUTPUT HEALTH")
    print(f"  parse errors           : {s['parse_errors']}/{s['n']}")
    print(f"  repaired JSON          : {s['repaired']}")
    print(f"  keyword-only fallback  : {s['keyword_only']}")
    print(f"  mean response words    : {s['mean_response_words']}")
    print(f"  </think> loops         : {s['think_loops']}/{s['n']}")

    print("\nGROUNDING  (values checked against telemetry + network reference)")
    print(f"  strict  (exact match)  : {s['grounding_strict']:.3f}")
    print(f"  lenient (+derived rates): {s['grounding_lenient']:.3f}")
    print(f"  values checked         : {s['grounding_values_checked']}"
          f"  ({s['grounding_derived_forgiven']} forgiven as derived rates)")
    if s["unsupported_examples"]:
        print("  unsupported values seen:")
        for sid, bad in s["unsupported_examples"][:5]:
            print(f"    id={sid}: {bad}")

    print("\nREMEDIATION")
    print(f"  similarity to reference plan : {s['remediation_similarity']:.3f}")
    print(f"  critical-zone escalation ok  : {s['remediation_escalation_ok']:.3f}"
          f"  (n={s['remediation_escalation_n']})")
    print(f"  names the identified attacker: {s['remediation_names_attacker']:.3f}")
    print(f"  benign correctly silent      : {s['remediation_benign_silent']:.3f}")

    print("\n  confusion (row = truth):")
    for t in ATTACK_TYPES:
        if t in s["confusion"]:
            row = ", ".join(f"{k}:{v}" for k, v in sorted(s["confusion"][t].items()))
            print(f"    {t:<14} -> {row}")


def compare(a, b):
    print(f"\n{'='*70}\n{a['label']}  vs  {b['label']}\n{'='*70}")
    rows = [
        ("attack_type accuracy",   "accuracy"),
        ("macro F1",               "macro_f1"),
        ("binary attack/benign",   "binary_accuracy"),
        ("benign recall",          "benign_recall"),
        ("attacker_ip exact",      "attacker_ip_acc"),
        ("victim_ip exact",        "victim_ip_acc"),
        ("grounding strict",       "grounding_strict"),
        ("grounding lenient",      "grounding_lenient"),
        ("remediation similarity", "remediation_similarity"),
        ("escalation ok (crit.)",  "remediation_escalation_ok"),
        ("names attacker",         "remediation_names_attacker"),
        ("benign silent",          "remediation_benign_silent"),
    ]
    print(f"  {'metric':<26}{'first':>10}{'second':>12}{'delta':>10}")
    for name, key in rows:
        d = b[key] - a[key]
        print(f"  {name:<26}{a[key]:>10.3f}{b[key]:>12.3f}{d:>+10.3f}")
    print(f"  {'parse errors':<26}{a['parse_errors']:>10}{b['parse_errors']:>12}"
          f"{b['parse_errors']-a['parse_errors']:>+10}")
    print(f"  {'</think> loops':<26}{a['think_loops']:>10}{b['think_loops']:>12}"
          f"{b['think_loops']-a['think_loops']:>+10}")


if __name__ == "__main__":
    paths = sys.argv[1:] or ["results_baseline_full.json", "results_finetuned_full.json"]
    scores = []
    for p in paths:
        try:
            s = score_file(p)
        except FileNotFoundError:
            print(f"(skipping {p} -- not found)")
            continue
        scores.append(s)
        show(s)

    if len(scores) == 2:
        compare(scores[0], scores[1])

    with open("evaluation_report.json", "w", encoding="utf-8") as f:
        json.dump(scores, f, indent=2)
    print("\nFull report -> evaluation_report.json")
