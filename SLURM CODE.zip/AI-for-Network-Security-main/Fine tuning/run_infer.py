"""
run_infer.py — inference only, for either the plain base model or a
fine-tuned adapter, against the UniBonn-Mini test set.

Standalone usage:
    python run_infer.py --adapter none --truncate false
        -> results_baseline_full.json   (the "before" floor)

    python run_infer.py --adapter none --truncate true
        -> results_baseline_half.json

    python run_infer.py --adapter model_weights_unibonn_full --truncate false
        -> results_finetuned_full.json

    python run_infer.py --adapter model_weights_unibonn_half --truncate true
        -> results_finetuned_half.json

    python run_infer.py --adapter model_weights_unibonn_full --truncate false \\
        --output_path my_run.json --label my-label
        -> explicit output path and label

Also importable: run_pipeline.py calls infer(...) directly.
"""

import argparse
import os

import unibonn_pipeline as P

# Known adapters -> sensible default output name + label, so the common case
# (baseline or the two pipeline adapters) needs no extra arguments.
KNOWN_DEFAULTS = {
    "model_weights_unibonn_full": ("results_finetuned_full.json", "finetuned-full"),
    "model_weights_unibonn_half": ("results_finetuned_half.json", "finetuned-half"),
}


def _default_output_and_label(adapter: str, truncate: bool):
    suffix = "half" if truncate else "full"
    if adapter in (None, "none", ""):
        return f"results_baseline_{suffix}.json", f"baseline-{suffix}"
    base = os.path.basename(adapter.rstrip("/"))
    if base in KNOWN_DEFAULTS:
        return KNOWN_DEFAULTS[base]
    return f"results_{base}.json", base


def infer(test_path: str, adapter: str, truncate: bool,
          output_path: str = None, label: str = None):
    out, lbl = _default_output_and_label(adapter, truncate)
    output_path = output_path or out
    label = label or lbl

    samples = P.load_dataset(test_path)
    print(f"Loaded {len(samples)} test samples from {test_path}", flush=True)
    print(f"Adapter   : {adapter or '(none — plain base model)'}", flush=True)
    print(f"Truncate  : {truncate}", flush=True)
    print(f"Output    : {output_path}", flush=True)
    print(f"Label     : {label}", flush=True)

    model, tok = P.load_base_model(for_training=False)
    if adapter and adapter.lower() != "none":
        if not os.path.exists(os.path.join(adapter, "adapter_config.json")):
            raise FileNotFoundError(
                f"{adapter} has no adapter_config.json — is this the right "
                f"folder? (checkpoint-N subfolders also work)")
        model, _ = P.attach_adapter(model, adapter)
    model.eval()

    P.run_inference(model, tok, samples, output_path, label, truncate=truncate)
    P.unload(model, tok)


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--test_path", default="test_unibonn_tiers_with_remediation.json")
    ap.add_argument("--adapter", default="none",
                    help="adapter directory, or 'none' for the plain base model")
    ap.add_argument("--truncate", type=lambda s: s.lower() == "true", default=False,
                    help="true/false — half-length connection/ICMP logs")
    ap.add_argument("--output_path", default=None)
    ap.add_argument("--label", default=None)
    args = ap.parse_args()

    infer(args.test_path, args.adapter, args.truncate,
          args.output_path, args.label)
