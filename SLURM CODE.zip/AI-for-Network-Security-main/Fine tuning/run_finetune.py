"""
run_finetune.py — fine-tune a FRESH LoRA on the plain DeepSeek base model
using the UniBonn-Mini train set (with zone-based remediation).

There is no prior adapter to continue from in this project -- the baseline
IS the plain pretrained model (see run_infer.py --adapter none). This script
always starts a brand-new LoRA.

Two truncation conditions matter, and each gets its OWN adapter, because
training and inference should see matching prompt distributions:
    --truncate false  (default)  -> model_weights_unibonn_full/
    --truncate true               -> model_weights_unibonn_half/

Standalone usage:
    python run_finetune.py                       # full logs
    python run_finetune.py --truncate            # half logs
    python run_finetune.py --train_path X.json --out_dir custom_dir/

Also importable: run_pipeline.py calls finetune(...) directly.
"""

import argparse
import json
import os
import gc
import random

import torch
from torch.utils.data import Dataset
from transformers import TrainingArguments, Trainer
from peft import prepare_model_for_kbit_training

import unibonn_pipeline as P


NUM_EPOCHS    = 3
LEARNING_RATE = 2e-4       # fresh LoRA, starts from zero -- needs a real step
BATCH_SIZE    = 1
GRAD_ACCUM    = 8
WARMUP_RATIO  = 0.03
WEIGHT_DECAY  = 0.01
EVAL_FRACTION = 0.1


class UniBonnSFT(Dataset):
    """Completion-only loss masking: prompt tokens are set to -100 so the
    model is not trained to reproduce the (large, fixed) network-reference
    block and telemetry -- only to produce the JSON answer."""

    def __init__(self, samples, tokenizer, truncate, max_length=P.MAX_SEQ_LENGTH):
        self.examples = []
        skipped = 0
        for s in samples:
            prompt = P.build_prompt(s, truncate=truncate)
            target = P.build_target(s)
            full = prompt + target + tokenizer.eos_token

            prompt_ids = tokenizer(prompt, add_special_tokens=False)["input_ids"]
            full_ids = tokenizer(full, add_special_tokens=False,
                                 truncation=True, max_length=max_length)["input_ids"]

            if len(full_ids) <= len(prompt_ids) + 8:
                skipped += 1
                continue

            labels = list(full_ids)
            for i in range(min(len(prompt_ids), len(full_ids))):
                labels[i] = -100

            self.examples.append({
                "input_ids": full_ids,
                "labels": labels,
                "attention_mask": [1] * len(full_ids),
            })

        if skipped:
            print(f">>> WARNING: {skipped} samples dropped -- prompt+target "
                  f"exceeded MAX_SEQ_LENGTH={max_length}", flush=True)
        lens = [len(e["input_ids"]) for e in self.examples]
        print(f">>> {len(self.examples)} training examples, "
              f"token length min={min(lens)} max={max(lens)} "
              f"mean={sum(lens)//len(lens)}", flush=True)

    def __len__(self):
        return len(self.examples)

    def __getitem__(self, i):
        return self.examples[i]


def make_collate_fn(pad_id):
    def collate(batch):
        m = max(len(x["input_ids"]) for x in batch)
        ii, ll, aa = [], [], []
        for x in batch:
            pad = m - len(x["input_ids"])
            ii.append(x["input_ids"] + [pad_id] * pad)
            ll.append(x["labels"] + [-100] * pad)
            aa.append(x["attention_mask"] + [0] * pad)
        return {"input_ids": torch.tensor(ii),
                "labels": torch.tensor(ll),
                "attention_mask": torch.tensor(aa)}
    return collate


def finetune(train_path: str, out_dir: str, truncate: bool):
    print(f">>> Loading plain base model {P.BASE_MODEL_NAME} for training "
          f"(truncate={truncate}) ...", flush=True)
    model, tok = P.load_base_model(for_training=True)

    if P.LOAD_IN_4BIT:
        model = prepare_model_for_kbit_training(model)

    model, _ = P.build_fresh_adapter(model)
    model.print_trainable_parameters()
    model.enable_input_require_grads()
    model.gradient_checkpointing_enable()

    samples = P.load_dataset(train_path)
    print(f">>> Loaded {len(samples)} training samples from {train_path}", flush=True)

    rng = random.Random(1234)
    idx = list(range(len(samples)))
    rng.shuffle(idx)
    n_eval = max(1, int(len(samples) * EVAL_FRACTION))
    eval_idx = set(idx[:n_eval])
    train_samples = [s for i, s in enumerate(samples) if i not in eval_idx]
    eval_samples  = [s for i, s in enumerate(samples) if i in eval_idx]
    print(f">>> train {len(train_samples)} / held-out {len(eval_samples)}", flush=True)

    train_ds = UniBonnSFT(train_samples, tok, truncate)
    eval_ds  = UniBonnSFT(eval_samples, tok, truncate)

    args = TrainingArguments(
        output_dir=out_dir,
        num_train_epochs=NUM_EPOCHS,
        per_device_train_batch_size=BATCH_SIZE,
        per_device_eval_batch_size=BATCH_SIZE,
        gradient_accumulation_steps=GRAD_ACCUM,
        learning_rate=LEARNING_RATE,
        lr_scheduler_type="cosine",
        warmup_ratio=WARMUP_RATIO,
        weight_decay=WEIGHT_DECAY,
        logging_steps=10,
        eval_strategy="epoch",
        save_strategy="epoch",
        save_total_limit=NUM_EPOCHS,
        report_to="none",
        bf16=True,
        fp16=False,
        gradient_checkpointing=True,
        optim="paged_adamw_8bit" if P.LOAD_IN_4BIT else "adamw_torch",
    )

    trainer = Trainer(
        model=model,
        args=args,
        train_dataset=train_ds,
        eval_dataset=eval_ds,
        data_collator=make_collate_fn(tok.pad_token_id),
    )

    trainer.train()

    model.save_pretrained(out_dir)
    tok.save_pretrained(out_dir)
    with open(os.path.join(out_dir, "training_log.json"), "w") as f:
        json.dump(trainer.state.log_history, f, indent=2)
    print(f">>> Adapter saved to {out_dir}", flush=True)

    del trainer, model, tok
    gc.collect()
    torch.cuda.empty_cache()


def _default_out_dir(truncate: bool) -> str:
    return "model_weights_unibonn_half" if truncate else "model_weights_unibonn_full"


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--train_path", default="train_unibonn_tiers_with_remediation.json")
    ap.add_argument("--out_dir", default=None,
                    help="default: model_weights_unibonn_full/ or _half/ "
                         "depending on --truncate")
    ap.add_argument("--truncate", action="store_true",
                    help="train on half-length connection/ICMP logs "
                         "(summary block always kept whole)")
    args = ap.parse_args()

    out_dir = args.out_dir or _default_out_dir(args.truncate)
    finetune(args.train_path, out_dir, args.truncate)
