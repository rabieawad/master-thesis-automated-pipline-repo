#!/bin/bash
# ============================================================================
# SLURM job: fine-tune ONE truncation condition only (fresh LoRA on the
# plain base model), then run inference with the new adapter.
#
# SUBMIT WITH:   sbatch job_finetune.slurm full
#           or:  sbatch job_finetune.slurm half
# MONITOR WITH:  squeue --me   and   tail -f finetune_<jobid>.log
# ============================================================================
#SBATCH --job-name=ub_finetune
#SBATCH --partition=sgpu_long
#SBATCH --account=ag_ifi_martini
#SBATCH --gpus=1
#SBATCH --mem=90G
#SBATCH --time=16:00:00
#SBATCH --output=finetune_%j.log
#SBATCH --error=finetune_%j.log

set -euo pipefail
export SLURM_EXPORT_ENV=ALL

CONDITION="${1:?Usage: sbatch job_finetune.slurm <full|half>}"
if [[ "$CONDITION" != "full" && "$CONDITION" != "half" ]]; then
    echo "ERROR: condition must be 'full' or 'half', got '$CONDITION'"; exit 1
fi
TRUNC_FLAG=""
[[ "$CONDITION" == "half" ]] && TRUNC_FLAG="--truncate"

echo "Job $SLURM_JOBID starting on $(hostname) at $(date)"
echo ">>> Condition: $CONDITION"

module load Miniforge3
ENV_DIR="$HOME/envs/refinement"
ENV_PY="$ENV_DIR/bin/python"
source activate "$ENV_DIR"

export HF_HUB_DISABLE_XET=1
export HF_HOME="${TMPDIR:-/tmp}/hf_cache_$SLURM_JOBID"
mkdir -p "$HF_HOME"
echo ">>> HF cache for this job: $HF_HOME"

echo ">>> Preflight checks"
test -x "$ENV_PY" || { echo "ERROR: env Python not found"; exit 1; }
"$ENV_PY" -c "import torch, transformers, peft, accelerate, safetensors, bitsandbytes" \
    || { echo "ERROR: env missing packages (bitsandbytes is required for 4-bit)"; exit 1; }
test -f train_unibonn_tiers_with_remediation.json || { echo "ERROR: missing training data"; exit 1; }
test -f test_unibonn_tiers_with_remediation.json  || { echo "ERROR: missing test data"; exit 1; }
test -f unibonn_pipeline.py  || { echo "ERROR: missing unibonn_pipeline.py"; exit 1; }
test -f run_finetune.py      || { echo "ERROR: missing run_finetune.py"; exit 1; }
test -f run_infer.py         || { echo "ERROR: missing run_infer.py"; exit 1; }

echo ">>> Preflight OK"
nvidia-smi

echo ">>> Fine-tuning ($CONDITION) ..."
"$ENV_PY" run_finetune.py $TRUNC_FLAG

ADAPTER_DIR="model_weights_unibonn_${CONDITION}"
echo ">>> Inference with new adapter $ADAPTER_DIR ..."
"$ENV_PY" run_infer.py --adapter "$ADAPTER_DIR" --truncate "$([[ $CONDITION == half ]] && echo true || echo false)"

echo "Job $SLURM_JOBID finished at $(date)"
