"""
run_pipeline.py — orchestrates the full experiment: baseline inference,
fine-tuning, and post-finetune inference, for BOTH the full-log and
half-log truncation conditions.

This does not shell out to run_finetune.py / run_infer.py -- it imports and
calls their functions directly, so there is exactly one implementation of
each step; running the pipeline and running a stage standalone use the same
code path.

Produces four result files:
    results_baseline_full.json     (plain base model,   full logs)
    results_baseline_half.json     (plain base model,   half logs)
    results_finetuned_full.json    (fine-tuned adapter, full logs)
    results_finetuned_half.json    (fine-tuned adapter, half logs)

and two adapters:
    model_weights_unibonn_full/
    model_weights_unibonn_half/

Usage:
    python run_pipeline.py
    python run_pipeline.py --skip_baseline        # if you already have it
    python run_pipeline.py --only full             # just the full-log condition
    python run_pipeline.py --only half             # just the half-log condition
"""

import argparse

import run_finetune as FT
import run_infer as INF

TRAIN_PATH = "train_unibonn_tiers_with_remediation.json"
TEST_PATH  = "test_unibonn_tiers_with_remediation.json"


def run_condition(truncate: bool, skip_baseline: bool):
    suffix = "half" if truncate else "full"
    print(f"\n{'='*70}\nCONDITION: {suffix.upper()} LOGS\n{'='*70}", flush=True)

    if not skip_baseline:
        print(f">>> [1/3] Baseline inference ({suffix}) — plain base model", flush=True)
        INF.infer(TEST_PATH, adapter="none", truncate=truncate)
    else:
        print(f">>> [1/3] Skipping baseline inference ({suffix}) as requested", flush=True)

    adapter_dir = FT._default_out_dir(truncate)
    print(f"\n>>> [2/3] Fine-tuning ({suffix}) -> {adapter_dir}", flush=True)
    FT.finetune(TRAIN_PATH, adapter_dir, truncate)

    print(f"\n>>> [3/3] Post-finetune inference ({suffix})", flush=True)
    INF.infer(TEST_PATH, adapter=adapter_dir, truncate=truncate)


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--skip_baseline", action="store_true")
    ap.add_argument("--only", choices=["full", "half", "both"], default="both")
    args = ap.parse_args()

    if args.only in ("full", "both"):
        run_condition(truncate=False, skip_baseline=args.skip_baseline)
    if args.only in ("half", "both"):
        run_condition(truncate=True, skip_baseline=args.skip_baseline)

    print("\n>>> Pipeline complete. Run evaluate_unibonn.py to score all four "
          "result files.", flush=True)
