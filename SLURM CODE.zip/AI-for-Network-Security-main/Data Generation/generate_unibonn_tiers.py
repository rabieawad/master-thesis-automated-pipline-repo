#!/usr/bin/env python3
"""
generate_unibonn_tiers.py — Synthetic multi-telemetry dataset for UniBonn-Mini
using THREE-TIER network architecture.

Design:
  * Tier 1 (Public):        DMZ, guest, public portals (internet-facing)
  * Tier 2 (Institutional): Staff, students, shared services (requires auth)
  * Tier 3 (Critical):      AD, backups, research storage, core network (ops only)

  * 4 attacks (NO DNS spoofing):
    - SYN_Flood, ICMP_Flood, ARP_Spoofing, Port_Scan
  * 3 telemetry types (with PROPER PROTOCOL LAYER SEPARATION):
    - ARP cache, Connection log (TCP/UDP), ICMP log
  * 2 categories: real attack / clean normal

RENDERING CONTRACT (this is the important part)
-----------------------------------------------
Every log, in every category, is built from the same skeleton:

    header  ->  a random sample of individual packet/connection rows
            ->  a [SUMMARY] block with a fixed set of aggregate counters

Nothing about the *shape* of a log depends on the label:

  * No "[ANOMALOUS TRAFFIC]" section, no "(N total SYN attempts...)" trailer,
    no "within normal range" annotation, no "see separate ICMP log" pointer.
    Those strings were pure label leakage — their presence answered the task
    without reading a single packet.
  * Attack rows are NOT appended after the background rows. All rows for the
    window go into one pool and are shuffled, so a flood or a scan is
    interleaved with ordinary traffic exactly as it would be in a real
    capture. Position carries no information.
  * The rows shown are sampled proportionally from the pool, so the shown
    mix reflects the real mix rather than being a curated "20 of each".
  * The [SUMMARY] block always prints the same counter names in the same
    order, including zeros. Only the NUMBERS differ.
  * The state vocabulary (ESTABLISHED / SYN_SENT / RST / REFUSED) is shared:
    baseline traffic contains every state a scan or flood produces, at low
    volume. There is no keyword that only ever occurs under attack.
  * The PORT vocabulary is shared too — see below.

TIME WINDOW AND HOST CAPACITY
-----------------------------
Every sample is a snapshot of ONE host over ONE observation window (10-30 s),
and the same window is stamped on the connection log and the ICMP log. That
gives the reader — and the model — the denominator needed to convert absolute
counters into rates. Under this window a benign server produces ~10 pps of
new connections and ~5 pps of ICMP; a SYN flood pushes ~25-100 pps of half-
open sockets; an ICMP flood pushes ~40-125 pps of echo-requests.

The host has a TCP socket capacity of CAPACITY = 2000 (ESTABLISHED plus
SYN_SENT). This is the kernel's combined backlog and connection-table
ceiling. A SYN flood cannot make the observed socket count exceed it —
extra SYN attempts arrive but the kernel drops them, and the [SUMMARY]
line reports both the accepted count and how many were dropped. The
model therefore sees the physical reality: the backlog fills, ordinary
traffic starts being refused, and the observed SYN_SENT count plateaus
rather than growing unboundedly.

AGED SYN_SENT COUNTER
---------------------
Ordinary background traffic and a SYN flood can both produce SYN_SENT
entries. What distinguishes them is age: an ordinary half-open socket is
in the SYN handshake for a fraction of a second and then either becomes
ESTABLISHED or times out; a flood socket has been sitting in SYN_SENT for
seconds, past the handshake timeout, and never completes. Real `ss` output
encodes this in the `timer:` field on each socket. The summary here mirrors
that with an "(aged=N)" annotation on the SYN_SENT counter: aged is the
count of sockets that have been half-open longer than the handshake would
normally take. In benign windows aged is 0-1 (occasional genuine timeout);
in a SYN flood, aged is essentially the whole flood contribution.

So the separable signals are the ones we actually want learned:

    SYN_Flood    high aged SYN_SENT, one source, one destination port
    Port_Scan    one source, many distinct destination ports, RST/REFUSED heavy
    ICMP_Flood   high echo-request count, one source, replies not keeping up
    ARP_Spoofing a known IP answering with a MAC that is not its own

PORTS: ONE LISTENING MODEL, ONE PORT GENERATOR
----------------------------------------------
Earlier revisions kept two unrelated notions of "which ports exist":

  * a fixed 47-entry BG_PORT_POOL that benign traffic drew from, and
  * a jittered expansion around service seeds that scans drew from.

Because the two never overlapped, every Port_Scan sample contained at least
one destination port that no benign sample could ever contain, and no other
class did — a 100%/0% split. Memorising 47 numbers solved Port_Scan outright,
without reading a source IP, a state, or the summary. That is a worse shortcut
than the distinct_dst_ports count it was introduced to remove, and the token
audit could not see it.

There was a second, independent problem: TIER_OPEN_PORTS decided what answered
a scanner, while benign traffic opened ESTABLISHED sessions to whatever the
background pool happened to sample. The same port was therefore open to normal
clients and closed to the scanner in 598 of 600 windows. The dataset had no
consistent answer to "what is this host listening on".

Both are fixed by the same change:

  1. HOST_PORTS gives every host a FIXED listening set, derived from the
     services it runs. It is the single authority on what is open. ESTABLISHED
     only ever appears on a listening port — for background traffic and for a
     scanner's probes alike. RST/REFUSED only ever appears on a closed one.
     "10.2.0.20 serves SMB and SSH" becomes a stable fact the model can learn.

  2. port_set() is the ONLY source of non-listening destination ports, and it
     is called by both benign traffic and scans. Benign windows carry the
     stray connections every real server sees — stale clients, wrong-port
     scripts, internet background radiation — and those strays are drawn with
     the same clustering profiles (targeted / service / broad) as a scan's
     probes. No port value and no clustering shape belongs to one class.

BENIGN NOISE FLOOR — WHAT REAL SERVERS ACTUALLY SEE
---------------------------------------------------
An earlier revision, trying to stop the model from classifying a scan on
distinct_dst_ports or refusal count alone, widened the benign noise floor
until every normal window reported ~40 distinct destination ports and ~65
refusals per 20-second window. That is not what a healthy server produces —
it is a small port scan. Benign windows had been made scan-shaped in an
attempt to disguise real scans, which is worse than the shortcut it was
trying to remove: neither class is realistic any more, and the source
concentration that actually distinguishes them is drowned in noise.

This revision restores realistic benign volumes:

  * stray_ports_for(...) draws only a handful of stray destinations per
    window (a few misconfigured clients, some background radiation), not
    tens.
  * n_rst and n_ref sit in the single digits — a real `ss -tan` snapshot
    over 20 seconds shows a small tail of resets and refusals, not a
    steady stream.

The consequence: distinct_dst_ports and RST+REFUSED totals now separate
scans from benign windows cleanly. That is the correct outcome, because
a scan genuinely does touch more ports and produce more refusals than a
normal window — pretending otherwise trained the model on a fiction.

ICMP realism: the flood does not replace the ICMP log, it is added to it. The
window still contains other hosts pinging and being answered; the attacker is
simply the dominant source. An ICMP log whose every row shares one source IP
is not something a gateway ever sees.

NOTE ON THE REMOVED BENIGN TWINS
--------------------------------
This generator used to emit a third category, "benign": samples labelled
None that rendered an attack's telemetry pattern from a legitimate internal
source. They depended on a primary/secondary contradiction across channels,
and once the TCP state table and interface counters were removed the
contradiction had nowhere to live. The category is gone rather than patched.
"normal" is the only non-attack class.

Label schema (per sample):
  attack_type : SYN_Flood|ICMP_Flood|ARP_Spoofing|Port_Scan|None
  attacker_ip : IP or null
  victim_ip   : IP
  reasoning   : "" (filled later)

Run:  python3 generate_unibonn_tiers.py
Out:  train_unibonn_tiers.json   test_unibonn_tiers.json
"""

import json, random, re
from collections import Counter

# ── Attack → carrying telemetry channel ───────────────────────────────────────
SIGNAL_MAP = {
    "SYN_Flood":    "conn",
    "ICMP_Flood":   "icmp",
    "ARP_Spoofing": "arp",
    "Port_Scan":    "conn",
}
ATTACKS = list(SIGNAL_MAP.keys())

# Host TCP capacity: ESTABLISHED + SYN_SENT together cannot exceed this. It is
# the sum of the kernel's SYN backlog and the connection table on a modest
# server. A flood pushes SYN attempts through, but the observed socket count
# is capped here — the "dropped" excess is reported separately in the summary.
CAPACITY = 2000

# ── THREE-TIER TOPOLOGY ───────────────────────────────────────────────────────
TIERS = {
    "tier1": {
        "name": "Public",
        "net": "10.1.0",
        "gw": "10.1.0.1",
        "hosts": {
            "web-portal": "10.1.0.10",
            "mail-relay": "10.1.0.11",
        },
    },
    "tier2": {
        "name": "Institutional",
        "net": "10.2.0",
        "gw": "10.2.0.1",
        "hosts": {
            "staff-ws-01": "10.2.0.21",
            "staff-ws-02": "10.2.0.22",
            "file-srv":    "10.2.0.20",
            "email-srv":   "10.2.0.10",
            "ecampus-srv": "10.2.0.12",
        },
    },
    "tier3": {
        "name": "Critical",
        "net": "10.3.0",
        "gw": "10.3.0.1",
        "hosts": {
            "ad-server":        "10.3.0.10",
            "backup-srv":       "10.3.0.11",
            "research-storage": "10.3.0.20",
            "monitor-srv":      "10.3.0.30",
        },
    },
}

# Disjoint attacker IP pools (external sources), split-specific
EXT_POOL = {
    "train": ["198.51.100.%d" % i for i in range(2, 60)] + ["185.220.101.%d" % i for i in range(2, 40)],
    "test":  ["203.0.113.%d" % i for i in range(2, 60)] + ["45.33.32.%d" % i for i in range(2, 40)],
}

# Background-traffic pools, also split-specific so train/test IPs never overlap
BG_POOL = EXT_POOL

CRITICAL_TARGETS = {
    "tier1": ["web-portal", "mail-relay"],
    "tier2": ["file-srv", "email-srv", "ecampus-srv"],
    "tier3": ["ad-server", "backup-srv", "research-storage", "monitor-srv"],
}

# ── SERVICES AND PORTS ────────────────────────────────────────────────────────
SERVICE_PORTS = {
    "web":      [80, 443, 8000, 8080, 8443, 8888],
    "database": [1433, 3306, 5432, 6379, 27017],
    "ssh":      [22, 2222, 22000],
    "ldap":     [389, 636, 3268],
    "smb":      [139, 445],
    "mail":     [25, 110, 143, 587, 993],
    "dns":      [53, 5353],
    "endpoint": [3389, 5900, 5985],
    "monitor":  [161, 5601, 9090, 9100],
}

COMMON_PORTS = [21, 22, 23, 25, 53, 80, 110, 143, 443, 445, 3306, 3389, 5432, 8080]

# What each host actually listens on.
HOST_SERVICES = {
    "web-portal":       ["web"],
    "mail-relay":       ["mail"],
    "staff-ws-01":      ["endpoint"],
    "staff-ws-02":      ["endpoint"],
    "file-srv":         ["smb", "ssh"],
    "email-srv":        ["mail", "ssh"],
    "ecampus-srv":      ["web", "database"],
    "ad-server":        ["ldap", "smb", "dns"],
    "backup-srv":       ["ssh", "smb"],
    "research-storage": ["ssh", "smb"],
    "monitor-srv":      ["monitor", "web", "ssh"],
}

HOST_PORTS = {}
for _t in TIERS.values():
    for _name, _ip in _t["hosts"].items():
        HOST_PORTS[_ip] = frozenset(
            p for svc in HOST_SERVICES[_name] for p in SERVICE_PORTS[svc]
        )

# Connection states, in the fixed order the summary always prints them.
CONN_STATES = ["ESTABLISHED", "SYN_SENT", "RST", "REFUSED"]

# ── FIXED MAC ADDRESS MAPPING (for ARP spoofing detection) ────────────────────
MAC_MAP = {
    "10.1.0.1":  "aa:bb:cc:00:00:01",
    "10.1.0.10": "aa:bb:cc:00:00:02",
    "10.1.0.11": "aa:bb:cc:00:00:03",
    "10.2.0.1":  "aa:bb:cc:00:00:06",
    "10.2.0.10": "aa:bb:cc:00:00:07",
    "10.2.0.12": "aa:bb:cc:00:00:08",
    "10.2.0.20": "aa:bb:cc:00:00:09",
    "10.2.0.21": "aa:bb:cc:00:00:0a",
    "10.2.0.22": "aa:bb:cc:00:00:0b",
    "10.3.0.1":  "aa:bb:cc:00:00:0f",
    "10.3.0.10": "aa:bb:cc:00:00:10",
    "10.3.0.11": "aa:bb:cc:00:00:11",
    "10.3.0.20": "aa:bb:cc:00:00:12",
    "10.3.0.30": "aa:bb:cc:00:00:13",
}

MAC_PREFIX = "aa:bb:cc"


def rnd_time():
    return f"{random.randint(0,23):02d}:{random.randint(0,59):02d}:{random.randint(0,59):02d}"


KNOWN_MAC_SUFFIXES = {m.rsplit(":", 1)[1] for m in MAC_MAP.values()}


def rogue_mac_for():
    """
    A rogue MAC drawn from the SAME vendor space as the legitimate hosts, so
    the shortcut "unfamiliar OUI = spoof" doesn't work — the model has to
    notice that this IP's MAC is different from what it always is.
    """
    while True:
        b4, b5, b6 = (random.randint(0, 255) for _ in range(3))
        if b4 == 0 and b5 == 0 and f"{b6:02x}" in KNOWN_MAC_SUFFIXES:
            continue
        return f"{MAC_PREFIX}:{b4:02x}:{b5:02x}:{b6:02x}"


def pick_attacker(split, victim_tier):
    """Attacker IP based on victim tier, modelling attack progression."""
    if victim_tier == "tier1":
        r = random.random()
        if r < 0.65:
            return (random.choice(EXT_POOL[split]), "external")
        elif r < 0.95:
            return (f"10.1.0.{random.randint(60,250)}", "tier1")
        else:
            return (f"10.2.0.{random.randint(60,250)}", "tier2")

    if victim_tier == "tier2":
        r = random.random()
        if r < 0.05:
            return (f"10.3.0.{random.randint(60,250)}", "tier3")
        elif random.random() < 0.5:
            return (f"10.1.0.{random.randint(60,250)}", "tier1")
        else:
            return (f"10.2.0.{random.randint(60,250)}", "tier2")

    if random.random() < 0.5:
        return (f"10.2.0.{random.randint(60,250)}", "tier2")
    return (f"10.3.0.{random.randint(60,250)}", "tier3")


# ── Port selection ────────────────────────────────────────────────────────────

def _wander(seeds, n, radius):
    seeds_sorted = sorted(seeds)
    cands = set(seeds_sorted)
    while len(cands) < n:
        cands.add(random.choice(seeds_sorted) + random.randint(-radius, radius))
        cands = {p for p in cands if 1 <= p <= 65535}
        radius += 1
    return cands


def port_set(n):
    """
    n destination ports with realistic clustering. Used by BOTH benign strays
    and scan probes so no port value is exclusive to either class.
    """
    profile = random.choices(
        ["targeted", "service", "broad"], weights=[35, 40, 25], k=1
    )[0]

    if profile == "targeted":
        service_type = "multi_service"
        seeds = set()
        for st in random.sample(list(SERVICE_PORTS), random.randint(2, 4)):
            seeds |= set(SERVICE_PORTS[st])
        candidates = _wander(seeds, n, 8)

    elif profile == "service":
        service_type = random.choice(list(SERVICE_PORTS))
        candidates = _wander(set(SERVICE_PORTS[service_type]), n, 25)

    else:  # broad
        service_type = "sweep"
        start = random.choice([1, 20, 1024, 5000, 8000])
        candidates = set(range(start, start + n + 40)) | set(COMMON_PORTS)

    k = min(len(candidates), n)
    return sorted(random.sample(sorted(candidates), k)), profile, service_type


def stray_ports_for(victim_ip, n):
    open_set = HOST_PORTS[victim_ip]
    for _ in range(8):
        ports = [p for p in port_set(n)[0] if p not in open_set]
        if ports:
            return ports
    return [random.randint(1024, 65535)]


# ── Row sampling ──────────────────────────────────────────────────────────────

def sample_rows(groups, k):
    """
    Draw k display rows in proportion to how much traffic each group
    represents, then shuffle. Keeps attack rows interleaved with baseline
    instead of appended.
    """
    groups = [(c, f) for c, f in groups if c > 0]
    total = sum(c for c, _ in groups)
    if total == 0:
        return [], 0
    weights = [c for c, _ in groups]
    k = min(k, total)
    rows = [random.choices(groups, weights=weights, k=1)[0][1]() for _ in range(k)]
    random.shuffle(rows)
    return rows, total


def eph():
    return random.randint(1024, 65535)


def endpoint(ip, port):
    return f"{ip}:{port}".ljust(21)


# ── Telemetry builders ────────────────────────────────────────────────────────

def tel_arp(host, ip, tier_name, level, rogue_mac):
    """
    ARP cache. Legitimate entries always use the fixed MAC_MAP address, so a
    changed MAC is the detectable signal. level=2 poisons exactly one entry.
    """
    tier = TIERS[tier_name]
    ts = rnd_time()

    items = [("gateway", tier["gw"])]
    critical_names = CRITICAL_TARGETS[tier_name]
    for name, ip_addr in tier["hosts"].items():
        if name in critical_names and ip_addr != ip:
            items.append((name, ip_addr))

    if tier_name == "tier1":
        items.append(("t2-gateway", TIERS["tier2"]["gw"]))
    elif tier_name == "tier2":
        items.append(("t3-gateway", TIERS["tier3"]["gw"]))

    poisoned = set()
    if level == 2:
        candidates = [tier["gw"]] + [a for n, a in items if n in critical_names]
        poisoned = {random.choice(candidates)}

    rows = []
    for name, hip in items:
        mac = rogue_mac if hip in poisoned else MAC_MAP[hip]
        rows.append(f"  {hip:<14} ether {mac}")

    poisoned_ips = [hip for _, hip in items if hip in poisoned]
    names = {hip: n for n, hip in items}
    text = f"ARP cache {host} ({ip}) {ts}\n" + "\n".join(rows)
    return text, {
        "poisoned_ips": poisoned_ips,
        "poisoned_names": [names[p] for p in poisoned_ips],
        "expected_macs": {p: MAC_MAP[p] for p in poisoned_ips if p in MAC_MAP},
        "arp_entries": len(items),
    }


def tel_icmp(gw_name, gw_ip, victim_ip, src_ip, level, split, win, shown=40):
    """
    ICMP-only log (Layer 3, no ports). Baseline is the ordinary reachability
    traffic every gateway sees — a handful of external monitors and internal
    peers pinging and being answered. A flood is ADDED to that baseline; other
    hosts keep pinging and being answered while the attacker dominates the
    packet count. `win` is the observation window shared with the connection
    log, so rates (pps) are directly comparable across the two channels.
    """
    ts = rnd_time()
    header = (f"ICMP log {gw_name} ({gw_ip}) {ts}  "
              f"[window={win}s, Layer 3 only - no ports]")

    peers = [random.choice(BG_POOL[split]) for _ in range(random.randint(4, 10))]
    peers += [f"10.{random.choice([1,2,3])}.0.{random.randint(30,59)}"
              for _ in range(random.randint(1, 3))]

    # One echo IDENTIFIER per sending host (in reality, per ping process). A
    # flood driven by a single process is thousands of packets sharing one id.
    peer_id = {p: random.randint(1, 65535) for p in peers}
    flood_id = random.randint(1, 65535)

    # Baseline rate: ~2-6 pps of echo-requests across all monitors.
    n_req = random.randint(int(2*win), int(6*win))
    n_rep = int(n_req * random.uniform(0.80, 0.98))

    def bg_request():
        peer = random.choice(peers)
        return (f"  ICMP echo-request from {peer:<15} to {victim_ip} "
                f"id={peer_id[peer]} seq={random.randint(1,65535)}")

    def bg_reply():
        peer = random.choice(peers)
        return (f"  ICMP echo-reply   from {victim_ip:<15} to {peer} "
                f"id={peer_id[peer]} seq={random.randint(1,65535)}")

    groups = [(n_req, bg_request), (n_rep, bg_reply)]

    n_flood = 0
    if level == 2:
        # Flood rate: ~40-125 pps of echo-requests from a single source.
        n_flood = random.randint(int(40*win), int(125*win))

        def flood_request():
            return (f"  ICMP echo-request from {src_ip:<15} to {victim_ip} "
                    f"id={flood_id} seq={random.randint(1,4000)}")

        groups.append((n_flood, flood_request))

    rows, total = sample_rows(groups, shown)

    n_sources = len(set(peers)) + (1 if n_flood else 0)
    summary = [
        "",
        "  [SUMMARY]",
        f"  window={win}s  packets={total}  sampled={len(rows)}  "
        f"distinct_sources={n_sources}",
        f"  echo-request={n_req + n_flood}  echo-reply={n_rep}  "
        f"distinct_ids={len(set(peer_id.values())) + (1 if n_flood else 0)}",
    ]

    text = "\n".join([header, ""] + rows + summary)
    return text, {
        "icmp_window": win,
        "icmp_packets": total,
        "icmp_sources": n_sources,
        "icmp_requests": n_req + n_flood,
        "icmp_replies": n_rep,
        "icmp_flood_packets": n_flood,
        "icmp_baseline_requests": n_req,
    }


def tel_conn(gw_name, gw_ip, victim_ip, src_ip, level, split, atype, port,
             win, shown=45):
    """
    TCP/UDP connection log (ICMP-free — netstat/ss semantics). One pool of
    connections per window; sampled proportionally so attack rows interleave
    with baseline. Invariants: ESTABLISHED and SYN_SENT only on the host's real
    listening ports; RST and REFUSED only off them. Total ESTABLISHED+SYN_SENT
    is capped at CAPACITY; a SYN flood whose attempts would exceed the cap is
    clipped, and the drop count is reported in the summary.
    """
    ts = rnd_time()

    bg_ip_pool = [random.choice(BG_POOL[split]) for _ in range(random.randint(8, 25))]
    open_ports = sorted(HOST_PORTS[victim_ip])
    stray = stray_ports_for(victim_ip, random.randint(0, 10))

    # Baseline: ~150-400 established sessions and ~10-50 sockets briefly in
    # handshake. "aged" is the count of half-open sockets that have been
    # SYN_SENT past the handshake timeout — for benign traffic, essentially
    # zero; the exceptional case is 1 stuck socket per window.
    n_est = random.randint(150, 400)
    n_syn_recent = random.randint(10, 50)
    n_syn_aged = random.choices([0, 1], weights=[95, 5], k=1)[0]

    n_rst = random.randint(0, 10)
    n_ref = random.randint(0, 10)

    def bg_row(state, ports):
        def make():
            return ("  " + endpoint(random.choice(bg_ip_pool), eph())
                    + " -> " + endpoint(victim_ip, random.choice(ports))
                    + " " + state)
        return make

    groups = [
        (n_est, bg_row("ESTABLISHED", open_ports)),
        (n_syn_recent + n_syn_aged, bg_row("SYN_SENT", open_ports)),
        (n_rst, bg_row("RST", stray)),
        (n_ref, bg_row("REFUSED", stray)),
    ]

    dst_ports = set(open_ports) | set(stray)
    meta = {}

    if level > 0 and atype == "SYN_Flood":
        # ~25-100 pps of SYN attempts from one source to one listening port.
        requested = random.randint(int(25*win), int(100*win))

        # Cap total sockets at CAPACITY. The kernel drops the excess.
        available = max(0, CAPACITY - n_est - n_syn_recent - n_syn_aged)
        accepted = min(requested, available)
        dropped = requested - accepted

        n_syn_aged += accepted  # flood sockets sit in SYN_SENT past timeout

        def flood_row():
            return ("  " + endpoint(src_ip, eph())
                    + " -> " + endpoint(victim_ip, port) + " SYN_SENT")

        groups.append((accepted, flood_row))
        dst_ports.add(port)
        meta["syn_attempts_accepted"] = accepted
        meta["syn_attempts_dropped"] = dropped
        meta["syn_attempts_requested"] = requested

    elif level > 0 and atype == "Port_Scan":
        # 25-100 ports drawn from the same generator benign strays use.
        scanned, profile, service_type = port_set(random.randint(25, 100))

        open_set = HOST_PORTS[victim_ip]
        resp = {p: ("ESTABLISHED" if p in open_set
                    else random.choice(["RST", "REFUSED"])) for p in scanned}
        n_open = sum(1 for p in scanned if resp[p] == "ESTABLISHED")
        for p in scanned:
            if resp[p] == "ESTABLISHED":
                n_est += 1
            elif resp[p] == "RST":
                n_rst += 1
            else:
                n_ref += 1

        def scan_row():
            p = random.choice(scanned)
            return ("  " + endpoint(src_ip, eph())
                    + " -> " + endpoint(victim_ip, p) + " " + resp[p])

        groups.append((len(scanned), scan_row))
        dst_ports |= set(scanned)
        meta.update({
            "scan_refused": sum(1 for p in scanned if resp[p] != "ESTABLISHED"),
            "ports_scanned": len(scanned),
            "scan_strategy": service_type,
            "scan_profile": profile,
            "scan_open_ports": n_open,
        })

    # ICMP_Flood and ARP_Spoofing are absent by design: layer 3 and layer 2
    # respectively — the TCP/UDP connection log has nothing to show and is
    # left at pure baseline.

    rows, total = sample_rows(groups, shown)

    n_syn_total = n_syn_recent + n_syn_aged
    counts = {"ESTABLISHED": n_est, "SYN_SENT": n_syn_total,
              "RST": n_rst, "REFUSED": n_ref}
    n_sources = len(set(bg_ip_pool)) + (1 if meta else 0)

    dropped_str = (f"  dropped={meta['syn_attempts_dropped']} (capacity reached)"
                   if meta.get("syn_attempts_dropped", 0) > 0 else "")
    summary_lines = [
        "",
        "  [SUMMARY]",
        f"  window={win}s  connections={total}  capacity={CAPACITY}  "
        f"sampled={len(rows)}",
        f"  distinct_sources={n_sources}  distinct_dst_ports={len(dst_ports)}",
        (f"  states: ESTABLISHED={n_est}  "
         f"SYN_SENT={n_syn_total} (aged={n_syn_aged})  "
         f"RST={n_rst}  REFUSED={n_ref}"),
    ]
    if dropped_str:
        summary_lines.append(dropped_str)

    header = f"Conn log {gw_name} ({gw_ip}) {ts}"
    text = "\n".join([header, ""] + rows + summary_lines)

    meta.update({
        "conn_window": win,
        "conn_total": total,
        "conn_sources": n_sources,
        "conn_dst_ports": len(dst_ports),
        "conn_states": counts,
        "conn_syn_aged": n_syn_aged,
        "conn_syn_recent": n_syn_recent,
        "conn_baseline_refused": n_rst + n_ref - meta.get("scan_refused", 0),
    })
    return text, meta


# ── Reasoning ─────────────────────────────────────────────────────────────────

def _arp_line(atype, m):
    if atype == "ARP_Spoofing":
        pip = m["poisoned_ips"][0]
        name = m["poisoned_names"][0]
        exp = m["expected_macs"].get(pip, "the address on record")
        return (f"ARP cache: {m['arp_entries']} entries, of which one is wrong. "
                f"{pip} ({name}) resolves to {m['rogue_mac']}, but that address "
                f"is registered to {exp}. The rogue MAC shares the {MAC_PREFIX} "
                f"vendor prefix of the legitimate hosts, so the binding, not the "
                f"prefix, is what identifies it.")
    return (f"ARP cache: {m['arp_entries']} entries, all resolving to their "
            f"registered MAC addresses. No duplicate or changed binding at "
            f"layer 2.")


def _conn_line(atype, m, victim_ip, attacker_ip, port):
    st = m["conn_states"]
    win = m["conn_window"]
    base = (f"Connection log: {m['conn_total']} connections in a "
            f"{win}s window from {m['conn_sources']} sources across "
            f"{m['conn_dst_ports']} destination ports; capacity is {CAPACITY} "
            f"sockets")

    if atype == "SYN_Flood":
        acc = m["syn_attempts_accepted"]
        drp = m["syn_attempts_dropped"]
        req = m["syn_attempts_requested"]
        cap_note = (f" — {req} SYN attempts arrived from {attacker_ip}, of "
                    f"which {acc} filled the remaining backlog and {drp} were "
                    f"dropped as the kernel hit its cap"
                    if drp > 0 else
                    f", and {acc} SYN attempts from {attacker_ip} landed inside "
                    f"the remaining backlog")
        return (base + cap_note + f". SYN_SENT is {st['SYN_SENT']} against "
                f"ESTABLISHED={st['ESTABLISHED']}, and {m['conn_syn_aged']} of "
                f"those half-open sockets are AGED past the handshake timeout "
                f"— they never became ESTABLISHED. On a healthy host aged is 0 "
                f"or 1. All aged sockets are from {attacker_ip} to "
                f"{victim_ip}:{port}.")

    if atype == "Port_Scan":
        answered = (f"{m['scan_open_ports']} were answered"
                    if m["scan_open_ports"] else "none were answered")
        return (base + f". A normal window on this host closes only a handful "
                f"of connections — around {m['conn_baseline_refused']} — as "
                f"stale clients hit ports it does not serve. Here "
                f"{attacker_ip} alone touches {m['ports_scanned']} distinct "
                f"ports in a {m['scan_profile']} pattern over the "
                f"{m['scan_strategy']} range, of which {m['scan_refused']} "
                f"came back RST or REFUSED and {answered}. That is one source "
                f"enumerating a service surface rather than using it.")

    return (base + f". SYN_SENT={st['SYN_SENT']} (aged={m['conn_syn_aged']}) "
            f"against ESTABLISHED={st['ESTABLISHED']} is an ordinary "
            f"half-open profile — sockets are transiting the handshake, not "
            f"stuck. RST={st['RST']} / REFUSED={st['REFUSED']} is the small "
            f"tail a healthy server always shows. Nothing anomalous at "
            f"layer 4.")


def _icmp_line(atype, m, victim_ip, attacker_ip):
    win = m["icmp_window"]
    rate = m["icmp_packets"] / win
    if atype == "ICMP_Flood":
        flood_rate = m["icmp_flood_packets"] / win
        return (f"ICMP log: {m['icmp_packets']} packets in {win}s "
                f"(~{rate:.0f} pps) from {m['icmp_sources']} sources, "
                f"{m['icmp_requests']} echo-requests against only "
                f"{m['icmp_replies']} echo-replies. {m['icmp_flood_packets']} "
                f"of the requests come from {attacker_ip} to {victim_ip} "
                f"(~{flood_rate:.0f} pps from that one source) and go "
                f"unanswered, while the remaining {m['icmp_baseline_requests']} "
                f"from other hosts are still being replied to normally — the "
                f"victim is saturated, not offline.")
    return (f"ICMP log: {m['icmp_packets']} packets in {win}s "
            f"(~{rate:.0f} pps) from {m['icmp_sources']} sources, "
            f"{m['icmp_requests']} echo-requests and {m['icmp_replies']} "
            f"echo-replies. Requests are spread across hosts and are being "
            f"answered, so this is ordinary reachability traffic.")


VERDICT = {
    "SYN_Flood": ("Verdict: SYN flood. Layer 2 and layer 3 are clean; the "
                  "anomaly is aged half-open sockets consuming the TCP "
                  "backlog."),
    "Port_Scan": ("Verdict: port scan (reconnaissance). Layer 2 and layer 3 "
                  "are clean; the anomaly is the port fan-out from a single "
                  "source in the connection log."),
    "ICMP_Flood": ("Verdict: ICMP flood. Layer 2 is clean and the TCP/UDP "
                   "connection log is at baseline; the anomaly is confined "
                   "to layer 3 volume in the ICMP log."),
    "ARP_Spoofing": ("Verdict: ARP cache poisoning. Layers 3 and 4 are still "
                     "at baseline — the attacker has positioned for "
                     "interception but has not yet generated abnormal "
                     "traffic. The ARP cache is the only telemetry carrying "
                     "this."),
    "None": ("Verdict: normal traffic. All three channels agree — correct "
             "MAC bindings, an ordinary connection state mix, and answered "
             "ICMP. No action beyond routine monitoring."),
}


def build_reasoning(atype, m, victim_ip, victim_tier, attacker_ip,
                    attacker_tier, port):
    lines = [
        _arp_line(atype, m),
        _conn_line(atype, m, victim_ip, attacker_ip, port),
        _icmp_line(atype, m, victim_ip, attacker_ip),
        VERDICT[atype],
    ]

    if atype == "None":
        lines.append(
            f"Attribution: none. Target {victim_ip} sits in "
            f"{TIERS[victim_tier]['name']} ({victim_tier}); all observed "
            f"sources are behaving as clients.")
    else:
        src_desc = ("an external host" if attacker_tier == "external"
                    else f"{TIERS[attacker_tier]['name']} ({attacker_tier})")
        if attacker_tier == "external":
            path = "an outside-in attack against an internet-facing tier"
        elif attacker_tier == victim_tier:
            path = "lateral movement within the tier"
        else:
            path = (f"a crossing from {attacker_tier} into {victim_tier}, "
                    f"i.e. movement toward "
                    f"{TIERS[victim_tier]['name'].lower()} assets")
        extra = ""
        if atype == "ARP_Spoofing":
            pip = m["poisoned_ips"][0]
            extra = (f" The poisoned entry is for {pip} "
                     f"({m['poisoned_names'][0]}), so traffic {victim_ip} "
                     f"sends to that host is what gets redirected to the "
                     f"attacker.")
        lines.append(
            f"Attribution: {attacker_ip} ({src_desc}) -> {victim_ip} "
            f"({TIERS[victim_tier]['name']}, {victim_tier}). This is {path}."
            + extra)

    return "\n".join(lines)


# ── Assemble one sample ───────────────────────────────────────────────────────

def build(sample_id, category, split, force_atype=None):
    tier_name = random.choice(list(TIERS))
    tier = TIERS[tier_name]

    vhost, vip = random.choice(list(tier["hosts"].items()))
    port = random.choice(sorted(HOST_PORTS[vip]))
    rogue_mac = rogue_mac_for()

    # ONE observation window per sample, shared by both connection log and
    # ICMP log — same host, same time period, same denominator.
    win = random.randint(10, 30)

    levels = {"arp": 0, "conn": 0, "icmp": 0}

    if category == "normal":
        atype = "None"
        atk_ip = None
        atk_tier = None
        src_ip = "0.0.0.0"
    else:
        atype = force_atype or random.choice(ATTACKS)
        atk_ip, atk_tier = pick_attacker(split, tier_name)
        src_ip = atk_ip
        levels[SIGNAL_MAP[atype]] = 2

    arp_text, arp_meta = tel_arp(vhost, vip, tier_name, levels["arp"], rogue_mac)
    conn_text, conn_meta = tel_conn(
        tier["name"] + "-gw", tier["gw"], vip, src_ip, levels["conn"], split,
        atype=atype, port=port, win=win,
    )
    icmp_text, icmp_meta = tel_icmp(
        tier["name"] + "-gw", tier["gw"], vip, src_ip, levels["icmp"], split,
        win=win,
    )

    tel = {
        "arp_neighbor_table": arp_text,
        "connection_log": conn_text,
        "icmp_log": icmp_text,
    }

    telemetry_details = {
        "attacker_ip": atk_ip,
        "victim_ip": vip,
        "victim_host": vhost,
        "victim_open_ports": sorted(HOST_PORTS[vip]),
        "target_port": port if atype == "SYN_Flood" else None,
        "rogue_mac": rogue_mac if atype == "ARP_Spoofing" else None,
        "category": category,
        "window": win,
        "capacity": CAPACITY,
    }
    telemetry_details.update(conn_meta)
    if atype == "ARP_Spoofing":
        telemetry_details["poisoned_ips"] = arp_meta["poisoned_ips"]
        telemetry_details["poisoned_count"] = len(arp_meta["poisoned_ips"])
        telemetry_details["expected_macs"] = arp_meta["expected_macs"]
    if atype == "ICMP_Flood":
        telemetry_details.update(icmp_meta)

    m = {}
    m.update(arp_meta)
    m.update(conn_meta)
    m.update(icmp_meta)
    m["rogue_mac"] = rogue_mac

    reasoning = build_reasoning(
        atype, m, vip, tier_name, atk_ip, atk_tier, port,
    )

    items = list(tel.items())
    random.shuffle(items)
    tel = dict(items)

    return {
        "id": sample_id,
        "split": split,
        "tier": tier_name,
        "tier_name": tier["name"],
        "category": category,
        "telemetry": tel,
        "telemetry_details": telemetry_details,
        "label": {
            "attack_type": atype,
            "attacker_ip": atk_ip,
            "attacker_tier": atk_tier,
            "victim_ip": vip,
            "victim_tier": tier_name,
            "reasoning": reasoning,
        },
    }


# ── Leakage audit ─────────────────────────────────────────────────────────────

CONN_ROW = re.compile(r"-> (\d+\.\d+\.\d+\.\d+):(\d+)\s+(\w+)")


def _dst_ports(sample):
    return {int(m.group(2))
            for m in CONN_ROW.finditer(sample["telemetry"]["connection_log"])}


def audit(data):
    """
    Guard against every leak this generator has ever had:

      1. token presence
      2. line counts
      3. port vocabulary (caught the BG_PORT_POOL leak)
      4. benign-window realism  (caught the "scan-shaped normals" leak)
      5. capacity ceiling       (guards the CAPACITY invariant)
      6. window consistency     (conn window == icmp window per sample)
    """
    atk = [d for d in data if d["category"] != "normal"]
    nrm = [d for d in data if d["category"] == "normal"]

    def frac(group, token):
        if not group:
            return 0.0
        return sum(1 for d in group
                   if any(token in v for v in d["telemetry"].values())) / len(group)

    tokens = ["[SUMMARY]", "SYN_SENT", "RST", "REFUSED", "ESTABLISHED",
              "echo-request", "echo-reply", "ANOMALOUS", "TRAFFIC PATTERN",
              "total_scanned", "normal range", "seq=", "aged=", "window="]

    worst = 0.0
    print("  leakage:  token                 attack%   normal%")
    for t in tokens:
        fa, fn = frac(atk, t), frac(nrm, t)
        worst = max(worst, abs(fa - fn))
        flag = "  <-- LEAK" if abs(fa - fn) > 0.05 else ""
        print(f"            {t:<20} {fa:7.1%}  {fn:7.1%}{flag}")
    print(f"  worst token gap: {worst:.1%} (expect 0.0%)")

    for ch in ("connection_log", "icmp_log", "arp_neighbor_table"):
        la = [d["telemetry"][ch].count("\n") for d in atk]
        ln = [d["telemetry"][ch].count("\n") for d in nrm]
        print(f"  lines {ch:<20} attack {min(la)}-{max(la)}   "
              f"normal {min(ln)}-{max(ln)}")

    half = len(nrm) // 2
    vocab = set().union(*[_dst_ports(d) for d in nrm[:half]]) if half else set()

    def oov(group):
        if not group:
            return 0.0, 0.0
        sample_lvl = sum(1 for d in group if _dst_ports(d) - vocab) / len(group)
        rates = [len(p - vocab) / len(p) for d in group if (p := _dst_ports(d))]
        return sample_lvl, (sum(rates) / len(rates) if rates else 0.0)

    print("  port vocabulary (built from half the normal samples):")
    print("            class            any OOV port   OOV share of ports")
    groups = [("normal (held out)", nrm[half:])] + [
        (a, [d for d in atk if d["label"]["attack_type"] == a]) for a in ATTACKS
    ]
    for label, g in groups:
        s, r = oov(g)
        print(f"            {label:<16} {s:12.1%}   {r:17.1%}")

    bad = 0
    for d in data:
        openp = set(d["telemetry_details"]["victim_open_ports"])
        for mo in CONN_ROW.finditer(d["telemetry"]["connection_log"]):
            p, state = int(mo.group(2)), mo.group(3)
            if (state in ("ESTABLISHED", "SYN_SENT")) != (p in openp):
                bad += 1
                break
    print(f"  open/closed contradictions: {bad}/{len(data)} (expect 0)")

    scan_shaped_normal = sum(
        1 for d in nrm
        if d["telemetry_details"]["conn_dst_ports"] >= 25
        and d["telemetry_details"]["conn_states"]["RST"]
          + d["telemetry_details"]["conn_states"]["REFUSED"] >= 30
    )
    print(f"  benign windows with scan-shaped summary "
          f"(dst_ports>=25 AND RST+REFUSED>=30): "
          f"{scan_shaped_normal}/{len(nrm)} (expect 0)")

    # Capacity: total observed sockets never exceeds CAPACITY.
    over_cap = sum(
        1 for d in data
        if d["telemetry_details"]["conn_states"]["ESTABLISHED"]
         + d["telemetry_details"]["conn_states"]["SYN_SENT"] > CAPACITY
    )
    print(f"  sockets exceeding capacity ({CAPACITY}): "
          f"{over_cap}/{len(data)} (expect 0)")

    # Window consistency: same window on both logs of a sample.
    win_mismatch = 0
    for d in data:
        w1 = d["telemetry_details"]["window"]
        w2 = d["telemetry_details"].get("icmp_window", w1)
        cw = d["telemetry_details"].get("conn_window", w1)
        if not (w1 == w2 == cw):
            win_mismatch += 1
    print(f"  window mismatch (conn vs icmp vs sample): "
          f"{win_mismatch}/{len(data)} (expect 0)")

    def rng(group, key=lambda d: d["telemetry_details"]["conn_dst_ports"]):
        v = [key(d) for d in group]
        return f"{min(v)}-{max(v)}" if v else "-"
    scans = [d for d in atk if d["label"]["attack_type"] == "Port_Scan"]
    print(f"  distinct_dst_ports  normal {rng(nrm)}   "
          f"port-scan {rng(scans)}")
    ref_key = lambda d: (d["telemetry_details"]["conn_states"]["RST"]
                         + d["telemetry_details"]["conn_states"]["REFUSED"])
    print(f"  RST+REFUSED total   normal {rng(nrm, ref_key)}   "
          f"port-scan {rng(scans, ref_key)}")

    # SYN_Flood-specific: aged counter behaviour
    floods = [d for d in atk if d["label"]["attack_type"] == "SYN_Flood"]
    aged_normal = sorted(d["telemetry_details"]["conn_syn_aged"] for d in nrm)
    aged_flood  = sorted(d["telemetry_details"]["conn_syn_aged"] for d in floods)
    if aged_normal and aged_flood:
        print(f"  SYN aged  normal {aged_normal[0]}-{aged_normal[-1]}   "
              f"flood {aged_flood[0]}-{aged_flood[-1]}")

    dropped = [d["telemetry_details"].get("syn_attempts_dropped", 0)
               for d in floods]
    if dropped:
        n_cap_hit = sum(1 for x in dropped if x > 0)
        print(f"  SYN floods that hit capacity: {n_cap_hit}/{len(dropped)}")


# ── Generate a split ──────────────────────────────────────────────────────────

def gen_split(name, seed, split, counts):
    random.seed(seed)
    attack_plan = [ATTACKS[i % len(ATTACKS)] for i in range(counts["real"])]
    random.shuffle(attack_plan)
    plan = ([("real", a) for a in attack_plan]
            + [("normal", None)] * counts["normal"])
    random.shuffle(plan)

    data = [build(i + 1, cat, split, force_atype=a)
            for i, (cat, a) in enumerate(plan)]

    with open(f"{name}.json", "w") as f:
        json.dump({"total": len(data), "dataset": data}, f, indent=2)

    print(f"\n{name}: {len(data)} samples")
    print("  category:", dict(Counter(d["category"] for d in data)))
    print("  attack:  ", dict(Counter(d["label"]["attack_type"] for d in data)))
    print("  tier:    ", dict(Counter(d["tier"] for d in data)))
    audit(data)


if __name__ == "__main__":
    print("=" * 70)
    print("THREE-TIER UniBonn Network Telemetry Generator")
    print("=" * 70)
    print("\nTier Structure:")
    for tname, tdata in TIERS.items():
        print(f"  {tname.upper():8} ({tdata['name']:15}): {tdata['net']}.0/24")
    print()

    # 200 samples per attack × 4 attacks = 800 attack samples
    # 200 normal samples → 1000 total, balanced across 5 labels
    gen_split("train_unibonn_tiers", seed=1000, split="train",
              counts={"real": 800, "normal": 200})
    gen_split("test_unibonn_tiers", seed=2000, split="test",
              counts={"real": 200, "normal": 50})

    print("\nGenerated: train_unibonn_tiers.json, test_unibonn_tiers.json")
