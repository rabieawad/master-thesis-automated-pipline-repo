#!/usr/bin/env python3
"""
cyborg_style_simulator.py — a CybORG-style, pure-Python, no-reward simulator
for the UniBonn-Mini three-tier network.

WHAT "CYBORG-STYLE" MEANS HERE (and what it does NOT mean)
------------------------------------------------------------
CybORG is not a packet-level network simulator. Every host is a plain
Python object holding instance variables (which ports are in which state,
what its ARP cache currently says, etc). An action is a small object with a
pre-condition (can this happen right now?) and a post-condition (what does
it do to the state if it does?). A scenario runs for a fixed number of
discrete timesteps; each tick, agents each execute one action, and the
action's post-condition mutates the relevant host object directly. There is
no reward here (that is the RL half of CybORG, deliberately dropped) and no
red/blue agent choosing actions strategically — this file always simulates
exactly one attack (or none) per episode, which is a decision, not a
missing feature: it is what lets every episode still resolve to one clean,
single-attack-type label, which is what the downstream fine-tuning pipeline
expects.

WHAT ACTUALLY CHANGES vs. generate_unibonn_tiers.py
------------------------------------------------------------
generate_unibonn_tiers.py decides "this window has 1834 SYN attempts" with
one random.randint() call, then renders that decision as text. This file
instead runs a tick loop -- one tick per simulated second of the
observation window -- and at each tick, a background-traffic process and
(if this episode has one) an attack action each independently decide
whether something happens THIS tick and, if so, mutate the host's live
state: append a connection event, flip an ARP entry, log an ICMP packet.
The final counts you see in the rendered telemetry are not chosen up
front -- they are whatever accumulated over the course of the simulated
ticks, the same way a real capture's totals are a consequence of what
actually happened over the window, not a target the window was built to
hit.

Concretely, this makes three attacks visibly more "live" than before:
  * SynFloodAction checks the host's remaining TCP capacity EVERY TICK and
    refuses what doesn't fit at that moment, rather than computing one
    final min() at the end.
  * ArpSpoofAction RE-ASSERTS the poisoned binding every tick, the way a
    real attacker keeps re-broadcasting forged ARP replies to hold the
    poisoning in place against the victim's normal ARP refresh -- if the
    action stopped re-asserting, the binding would drift back to correct
    on its own (a background self-heal tick exists precisely so this
    matters).
  * PortScanAction advances through its port list a few ports per tick,
    so a scan that gets interrupted partway through a short window
    genuinely has scanned fewer ports than one running the whole window,
    instead of every scan sample independently rolling its own total.

Reuses generate_unibonn_tiers.py's topology, ports, MAC map, port-set
clustering, attacker-tier progression, and reasoning/verdict text verbatim
-- none of that is reimplemented, only HOW the underlying counts arise
before being fed into that same rendering code.

Usage
-----
    python cyborg_style_simulator.py                     # 20/class, 100 total
    python cyborg_style_simulator.py --per-class 25 --no-normal   # 100, 4 attacks only
    python cyborg_style_simulator.py --interval 2 --live          # print each attack tick as it happens
    python cyborg_style_simulator.py --out my_sim_dataset.json
"""

from __future__ import annotations

import argparse
import json
import random
import time
from collections import Counter

import generate_unibonn_tiers as G
import remediation_playbook as R


# --------------------------------------------------------------------------- #
# Host state
# --------------------------------------------------------------------------- #

class HostState:
    """
    Live, mutable state for one host over the course of one episode. Every
    field here is something a real network stack actually tracks -- this is
    the "instance variables that represent the system state" CybORG uses,
    applied to our topology.
    """

    def __init__(self, ip: str, name: str, tier: str):
        self.ip = ip
        self.name = name
        self.tier = tier
        self.open_ports = G.HOST_PORTS[ip]

        # Live event pools, appended to tick by tick, read off at the end.
        self.conn_events: list[dict] = []   # {src, sport, dport, state}
        self.icmp_events: list[dict] = []   # {kind, peer, id, seq}

        # ARP cache as this host currently sees it. Starts correct; an
        # ArpSpoofAction targeting this host overwrites one entry, and a
        # background self-heal tick nudges it back UNLESS the attack keeps
        # re-asserting the poison every tick.
        self.arp_cache: dict[str, str] = {}

    # -- capacity bookkeeping, checked live every tick by SynFloodAction ----
    def live_socket_count(self) -> int:
        return sum(1 for e in self.conn_events
                   if e["state"] in ("ESTABLISHED", "SYN_SENT"))


class NetworkState:
    """All hosts in the topology, keyed by IP. Built once per episode."""

    def __init__(self):
        self.hosts: dict[str, HostState] = {}
        for tier_name, tier in G.TIERS.items():
            for name, ip in tier["hosts"].items():
                self.hosts[ip] = HostState(ip, name, tier_name)

    def init_arp_cache(self, victim_ip: str, victim_tier: str, victim_name: str):
        """Populate the victim's ARP cache with the same neighbour set
        generate_unibonn_tiers.tel_arp() uses, all correct to start."""
        tier = G.TIERS[victim_tier]
        items = [("gateway", tier["gw"])]
        critical_names = G.CRITICAL_TARGETS[victim_tier]
        for name, ip_addr in tier["hosts"].items():
            if name in critical_names and ip_addr != victim_ip:
                items.append((name, ip_addr))
        if victim_tier == "tier1":
            items.append(("t2-gateway", G.TIERS["tier2"]["gw"]))
        elif victim_tier == "tier2":
            items.append(("t3-gateway", G.TIERS["tier3"]["gw"]))

        host = self.hosts[victim_ip]
        for _, ip in items:
            host.arp_cache[ip] = G.MAC_MAP[ip]
        return items  # neighbour list, needed later for rendering


# --------------------------------------------------------------------------- #
# Actions -- each has a pre-condition (can this fire this tick?) and a
# post-condition (what it does to state if it does)
# --------------------------------------------------------------------------- #

class BackgroundTraffic:
    """
    The 'green agent' -- ordinary users and services, ticking regardless of
    whether an attack is also running. Runs on every host every tick.
    """

    def __init__(self, state: NetworkState, split: str):
        self.state = state
        self.split = split
        self.bg_ip_pool = [random.choice(G.BG_POOL[split]) for _ in range(random.randint(8, 25))]
        self.peers = ([random.choice(G.BG_POOL[split]) for _ in range(random.randint(4, 10))]
                     + [f"10.{random.choice([1,2,3])}.0.{random.randint(30,59)}"
                        for _ in range(random.randint(1, 3))])
        self.peer_id = {p: random.randint(1, 65535) for p in self.peers}
        self._stray_cache: dict[str, list[int]] = {}

    def _stray_ports(self, host: HostState) -> list[int]:
        if host.ip not in self._stray_cache:
            self._stray_cache[host.ip] = G.stray_ports_for(host.ip, random.randint(0, 10))
        return self._stray_cache[host.ip]

    def tick(self, host: HostState, tick: int):
        # Pre-condition: none -- background traffic always happens somewhere.
        # Post-condition: a small number of ordinary events land on this
        # host -- UNLESS the host's socket table is already saturated (e.g.
        # by a concurrent SYN flood), in which case the attempt is simply
        # dropped rather than logged. It is tempting to log it as REFUSED,
        # but REFUSED on an open port would break the open/closed invariant
        # this whole dataset depends on (ESTABLISHED/SYN_SENT only on open
        # ports, RST/REFUSED only on closed ones) -- a capacity-exhausted
        # drop on an open port is neither; the honest rendering is that the
        # attempt never completed and never appears in the log at all,
        # which is exactly what "capacity reached" already communicates via
        # the flood's own dropped= counter.
        available = max(0, G.CAPACITY - host.live_socket_count())

        if random.random() < 0.9:  # established sessions land almost every tick
            n = random.randint(5, 20)
            for _ in range(n):
                if available <= 0:
                    break  # host saturated -- legitimate attempts silently fail
                host.conn_events.append({
                    "src": random.choice(self.bg_ip_pool), "sport": G.eph(),
                    "dport": random.choice(sorted(host.open_ports)),
                    "state": "ESTABLISHED",
                })
                available -= 1
        if random.random() < 0.5:  # brief half-open handshakes
            for _ in range(random.randint(0, 3)):
                if available <= 0:
                    break
                host.conn_events.append({
                    "src": random.choice(self.bg_ip_pool), "sport": G.eph(),
                    "dport": random.choice(sorted(host.open_ports)),
                    "state": "SYN_SENT", "opened_tick": tick,
                })
                available -= 1
        if random.random() < 0.3:  # occasional stray RST/REFUSED
            stray = self._stray_ports(host)
            state = random.choice(["RST", "REFUSED"])
            host.conn_events.append({
                "src": random.choice(self.bg_ip_pool), "sport": G.eph(),
                "dport": random.choice(stray), "state": state,
            })
        if random.random() < 0.4:  # ordinary ICMP reachability traffic
            peer = random.choice(self.peers)
            host.icmp_events.append({"kind": "request", "peer": peer,
                                     "id": self.peer_id[peer],
                                     "seq": random.randint(1, 65535)})
            if random.random() < 0.9:  # usually answered
                host.icmp_events.append({"kind": "reply", "peer": peer,
                                         "id": self.peer_id[peer],
                                         "seq": random.randint(1, 65535)})

        # ARP self-heal: if nothing is actively re-poisoning this entry, a
        # real host would eventually re-learn the correct binding on its own
        # (cache expiry + re-ARP). We only need this to matter for the ARP
        # entry currently under attack, so it's a no-op unless overridden.


class SynFloodAction:
    """Pre-condition: attack is active this tick. Post-condition: as many
    SYN_SENT sockets as the victim's REMAINING capacity allows land this
    tick; the rest are refused -- checked live, every tick, not decided
    once at the end."""

    def __init__(self, attacker_ip: str, victim_ip: str, port: int, rate_per_tick_range=(25, 100)):
        self.attacker_ip = attacker_ip
        self.victim_ip = victim_ip
        self.port = port
        self.rate_range = rate_per_tick_range
        self.total_requested = 0
        self.total_accepted = 0
        self.total_dropped = 0

    def tick(self, state: NetworkState, tick: int):
        host = state.hosts[self.victim_ip]
        requested = random.randint(*self.rate_range)
        self.total_requested += requested

        available = max(0, G.CAPACITY - host.live_socket_count())
        accepted = min(requested, available)
        dropped = requested - accepted
        self.total_accepted += accepted
        self.total_dropped += dropped

        for _ in range(accepted):
            host.conn_events.append({
                "src": self.attacker_ip, "sport": G.eph(), "dport": self.port,
                "state": "SYN_SENT", "opened_tick": tick, "aged": True,
            })


class IcmpFloodAction:
    """Pre-condition: attack active. Post-condition: a burst of unanswered
    echo-requests from the attacker lands this tick, on top of whatever
    background ICMP is also happening."""

    def __init__(self, attacker_ip: str, victim_ip: str, rate_per_tick_range=(40, 125)):
        self.attacker_ip = attacker_ip
        self.victim_ip = victim_ip
        self.rate_range = rate_per_tick_range
        self.flood_id = random.randint(1, 65535)
        self.total = 0

    def tick(self, state: NetworkState, tick: int):
        host = state.hosts[self.victim_ip]
        n = random.randint(*self.rate_range)
        self.total += n
        for _ in range(n):
            host.icmp_events.append({
                "kind": "request", "peer": self.attacker_ip,
                "id": self.flood_id, "seq": random.randint(1, 4000),
                "flood": True,
            })
        # deliberately no reply appended -- the flood's requests go unanswered


class PortScanAction:
    """Pre-condition: attack active. Post-condition: advances through a
    pre-drawn port list a few ports per tick -- a scan interrupted partway
    through a short window has genuinely covered less ground than one that
    ran the full window, which is new behaviour vs. the batch generator."""

    def __init__(self, attacker_ip: str, victim_ip: str, total_ports_range=(25, 100)):
        self.attacker_ip = attacker_ip
        self.victim_ip = victim_ip
        n = random.randint(*total_ports_range)
        self.ports, self.profile, self.strategy = G.port_set(n)
        self.cursor = 0
        self.probed: list[tuple[int, str]] = []  # (port, response)

    def tick(self, state: NetworkState, tick: int):
        if self.cursor >= len(self.ports):
            return
        host = state.hosts[self.victim_ip]
        probes_this_tick = random.randint(2, 6)
        for _ in range(probes_this_tick):
            if self.cursor >= len(self.ports):
                break
            port = self.ports[self.cursor]
            self.cursor += 1
            resp = ("ESTABLISHED" if port in host.open_ports
                    else random.choice(["RST", "REFUSED"]))
            self.probed.append((port, resp))
            host.conn_events.append({
                "src": self.attacker_ip, "sport": G.eph(), "dport": port,
                "state": resp,
            })


class ArpSpoofAction:
    """Pre-condition: attack active. Post-condition: RE-ASSERTS the forged
    binding on the victim's ARP cache every tick. This is the one action
    where 'every tick' is load-bearing: a real ARP-spoofing attacker keeps
    re-broadcasting forged replies to hold the poisoning in place, and if
    this action only fired once, the background self-heal logic would let
    the cache drift back to correct before the episode ends."""

    def __init__(self, attacker_ip: str, victim_ip: str, poisoned_ip: str, rogue_mac: str):
        self.attacker_ip = attacker_ip
        self.victim_ip = victim_ip
        self.poisoned_ip = poisoned_ip
        self.rogue_mac = rogue_mac

    def tick(self, state: NetworkState, tick: int):
        host = state.hosts[self.victim_ip]
        host.arp_cache[self.poisoned_ip] = self.rogue_mac  # re-assert every tick


# --------------------------------------------------------------------------- #
# Episode: build state, tick the loop, render telemetry as a byproduct
# --------------------------------------------------------------------------- #

def _sample_conn_rows(events: list[dict], victim_ip: str, k: int = 45):
    pool = list(events)
    random.shuffle(pool)
    shown = pool[:min(k, len(pool))]
    rows = []
    for e in shown:
        rows.append("  " + G.endpoint(e["src"], e["sport"]) + " -> "
                    + G.endpoint(victim_ip, e["dport"]) + " " + e["state"])
    return rows


def _sample_icmp_rows(events: list[dict], victim_ip: str, k: int = 40):
    pool = list(events)
    random.shuffle(pool)
    shown = pool[:min(k, len(pool))]
    rows = []
    for e in shown:
        if e["kind"] == "request":
            rows.append(f"  ICMP echo-request from {e['peer']:<15} to {victim_ip} "
                        f"id={e['id']} seq={e['seq']}")
        else:
            rows.append(f"  ICMP echo-reply   from {victim_ip:<15} to {e['peer']} "
                        f"id={e['id']} seq={e['seq']}")
    return rows


def run_episode(sample_id: int, category: str, split: str,
                force_atype: str | None, window_ticks_range=(10, 30),
                live: bool = False, interval: float = 0.0):
    """
    One full episode: pick victim/attacker (reusing generate_unibonn_tiers'
    own attacker-progression model exactly), build the state and the one
    action for this episode (if any), tick the loop, then render telemetry
    from whatever accumulated -- the byproduct-of-simulation step.
    """
    tier_name = random.choice(list(G.TIERS))
    tier = G.TIERS[tier_name]
    vhost, vip = random.choice(list(tier["hosts"].items()))
    port = random.choice(sorted(G.HOST_PORTS[vip]))
    rogue_mac = G.rogue_mac_for()
    window = random.randint(*window_ticks_range)

    if category == "normal":
        atype = "None"
        atk_ip, atk_tier = None, None
    else:
        atype = force_atype or random.choice(G.ATTACKS)
        atk_ip, atk_tier = G.pick_attacker(split, tier_name)

    state = NetworkState()
    neighbours = state.init_arp_cache(vip, tier_name, vhost)
    bg = BackgroundTraffic(state, split)

    action = None
    poisoned_ip = None
    if atype == "SYN_Flood":
        action = SynFloodAction(atk_ip, vip, port)
    elif atype == "ICMP_Flood":
        action = IcmpFloodAction(atk_ip, vip)
    elif atype == "Port_Scan":
        action = PortScanAction(atk_ip, vip)
    elif atype == "ARP_Spoofing":
        candidates = [ip for _, ip in neighbours]
        poisoned_ip = random.choice(candidates)
        action = ArpSpoofAction(atk_ip, vip, poisoned_ip, rogue_mac)

    # ---- tick loop: this is the actual simulation ----
    for tick in range(window):
        for host in state.hosts.values():
            bg.tick(host, tick)
        if action is not None:
            action.tick(state, tick)
        if live:
            tag = f"[{atype}]" if atype != "None" else "[normal]"
            print(f"  tick {tick+1}/{window}  {tag}  victim={vhost}", end="\r")
            if interval:
                time.sleep(interval)
    if live:
        print()

    victim = state.hosts[vip]

    # ---- render ARP cache from live state ----
    arp_rows = []
    for name, ip in [("gateway", tier["gw"])] + [
        (n, i) for n, i in tier["hosts"].items() if i != vip and
        n in G.CRITICAL_TARGETS[tier_name]
    ] + ([("t2-gateway", G.TIERS["tier2"]["gw"])] if tier_name == "tier1" else
        [("t3-gateway", G.TIERS["tier3"]["gw"])] if tier_name == "tier2" else []):
        mac = victim.arp_cache.get(ip, G.MAC_MAP.get(ip))
        arp_rows.append(f"  {ip:<14} ether {mac}")
    arp_text = f"ARP cache {vhost} ({vip}) {G.rnd_time()}\n" + "\n".join(arp_rows)

    arp_meta = {
        "poisoned_ips": [poisoned_ip] if poisoned_ip else [],
        "poisoned_names": ([n for n, i in neighbours if i == poisoned_ip]
                           if poisoned_ip else []),
        "expected_macs": ({poisoned_ip: G.MAC_MAP[poisoned_ip]} if poisoned_ip else {}),
        "arp_entries": len(neighbours),
    }

    # ---- render connection log from live accumulated events ----
    conn_events = victim.conn_events
    conn_rows = _sample_conn_rows(conn_events, vip)
    counts = Counter(e["state"] for e in conn_events)
    n_syn_aged = sum(1 for e in conn_events if e.get("aged"))
    dst_ports = {e["dport"] for e in conn_events}
    sources = {e["src"] for e in conn_events}

    conn_summary_extra = ""
    syn_meta = {}
    if isinstance(action, SynFloodAction):
        syn_meta = {
            "syn_attempts_requested": action.total_requested,
            "syn_attempts_accepted": action.total_accepted,
            "syn_attempts_dropped": action.total_dropped,
        }
        if action.total_dropped > 0:
            conn_summary_extra = f"\n  dropped={action.total_dropped} (capacity reached)"

    scan_meta = {}
    if isinstance(action, PortScanAction):
        n_open = sum(1 for _, r in action.probed if r == "ESTABLISHED")
        scan_meta = {
            "ports_scanned": len(action.probed),
            "scan_strategy": action.strategy,
            "scan_profile": action.profile,
            "scan_open_ports": n_open,
            "scan_refused": sum(1 for _, r in action.probed if r != "ESTABLISHED"),
        }

    conn_text = (
        f"Conn log {tier['name']}-gw ({tier['gw']}) {G.rnd_time()}\n\n"
        + "\n".join(conn_rows) + "\n\n  [SUMMARY]\n"
        f"  window={window}s  connections={len(conn_events)}  capacity={G.CAPACITY}  "
        f"sampled={len(conn_rows)}\n"
        f"  distinct_sources={len(sources)}  distinct_dst_ports={len(dst_ports)}\n"
        f"  states: ESTABLISHED={counts['ESTABLISHED']}  "
        f"SYN_SENT={counts['SYN_SENT']} (aged={n_syn_aged})  "
        f"RST={counts['RST']}  REFUSED={counts['REFUSED']}"
        + conn_summary_extra
    )

    baseline_refused = counts["RST"] + counts["REFUSED"] - scan_meta.get("scan_refused", 0)

    # ---- render ICMP log from live accumulated events ----
    icmp_events = victim.icmp_events
    icmp_rows = _sample_icmp_rows(icmp_events, vip)
    n_req = sum(1 for e in icmp_events if e["kind"] == "request")
    n_rep = sum(1 for e in icmp_events if e["kind"] == "reply")
    n_flood = sum(1 for e in icmp_events if e.get("flood"))
    icmp_sources = {e["peer"] for e in icmp_events}
    icmp_ids = {e["id"] for e in icmp_events}

    icmp_text = (
        f"ICMP log {tier['name']}-gw ({tier['gw']}) {G.rnd_time()}  "
        f"[window={window}s, Layer 3 only - no ports]\n\n"
        + "\n".join(icmp_rows) + "\n\n  [SUMMARY]\n"
        f"  window={window}s  packets={len(icmp_events)}  sampled={len(icmp_rows)}  "
        f"distinct_sources={len(icmp_sources)}\n"
        f"  echo-request={n_req}  echo-reply={n_rep}  distinct_ids={len(icmp_ids)}"
    )

    # ---- assemble meta dict exactly as build_reasoning()/_conn_line()/etc
    #      expect, then reuse them verbatim so reasoning text stays in the
    #      same voice as the batch-generated dataset ----
    m = dict(arp_meta)
    m.update(scan_meta)
    m.update(syn_meta)
    m.update({
        "conn_window": window, "conn_total": len(conn_events),
        "conn_sources": len(sources), "conn_dst_ports": len(dst_ports),
        "conn_states": {"ESTABLISHED": counts["ESTABLISHED"],
                        "SYN_SENT": counts["SYN_SENT"],
                        "RST": counts["RST"], "REFUSED": counts["REFUSED"]},
        "conn_syn_aged": n_syn_aged, "conn_baseline_refused": baseline_refused,
        "icmp_window": window, "icmp_packets": len(icmp_events),
        "icmp_sources": len(icmp_sources), "icmp_requests": n_req,
        "icmp_replies": n_rep, "icmp_flood_packets": n_flood,
        "icmp_baseline_requests": n_req - n_flood,
        "rogue_mac": rogue_mac,
    })

    reasoning = G.build_reasoning(atype, m, vip, tier_name, atk_ip, atk_tier, port)

    telemetry_details = {
        "attacker_ip": atk_ip, "victim_ip": vip, "victim_host": vhost,
        "victim_open_ports": sorted(G.HOST_PORTS[vip]),
        "target_port": port if atype == "SYN_Flood" else None,
        "rogue_mac": rogue_mac if atype == "ARP_Spoofing" else None,
        "category": category, "window": window, "capacity": G.CAPACITY,
        **{k: v for k, v in m.items() if k not in ("expected_macs",)},
    }
    if atype == "ARP_Spoofing":
        telemetry_details["poisoned_ips"] = arp_meta["poisoned_ips"]
        telemetry_details["poisoned_count"] = len(arp_meta["poisoned_ips"])
        telemetry_details["expected_macs"] = arp_meta["expected_macs"]

    tel = {"arp_neighbor_table": arp_text, "connection_log": conn_text,
           "icmp_log": icmp_text}
    items = list(tel.items())
    random.shuffle(items)
    tel = dict(items)

    sample = {
        "id": sample_id, "split": split, "tier": tier_name,
        "tier_name": tier["name"], "category": category,
        "telemetry": tel, "telemetry_details": telemetry_details,
        "label": {
            "attack_type": atype, "attacker_ip": atk_ip,
            "attacker_tier": atk_tier, "victim_ip": vip,
            "victim_tier": tier_name, "reasoning": reasoning,
        },
    }

    plan = R.generate_remediation(sample)
    sample["telemetry_details"]["remediation"] = plan["structured"]
    sample["label"]["remediation_text"] = plan["text"]
    sample["label"]["remediation_zone"] = plan["zone"]
    return sample


# --------------------------------------------------------------------------- #
# Dataset driver: run episodes until every class has n_per_class samples
# --------------------------------------------------------------------------- #

def run(n_per_class: int, include_normal: bool, split: str, seed: int | None,
        out_path: str, live: bool, interval: float):
    if seed is not None:
        random.seed(seed)

    classes = list(G.ATTACKS) + (["None"] if include_normal else [])
    plan = []
    for atk in G.ATTACKS:
        plan += [("real", atk)] * n_per_class
    if include_normal:
        plan += [("normal", None)] * n_per_class
    random.shuffle(plan)

    dataset = []
    counts = Counter()
    print(f">>> Simulating {len(plan)} episodes "
          f"({n_per_class} per class x {len(classes)} classes)...")
    for i, (category, atype) in enumerate(plan):
        sample = run_episode(i + 1, category, split, atype,
                             live=live, interval=interval)
        dataset.append(sample)
        counts[sample["label"]["attack_type"]] += 1
        if not live and (i + 1) % 10 == 0:
            print(f"  {i+1}/{len(plan)} episodes simulated", flush=True)

    print(f"\n>>> Done. Class counts: {dict(counts)}")

    with open(out_path, "w") as f:
        json.dump({"total": len(dataset), "dataset": dataset}, f, indent=2)
    print(f">>> Wrote {out_path}")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--per-class", type=int, default=20,
                    help="samples per class (default 20 x 5 classes = 100)")
    ap.add_argument("--no-normal", action="store_true",
                    help="exclude the normal-traffic class (4 attacks only)")
    ap.add_argument("--split", choices=["train", "test"], default="train")
    ap.add_argument("--seed", type=int, default=None)
    ap.add_argument("--out", default="simulated_unibonn_tiers.json")
    ap.add_argument("--live", action="store_true",
                    help="print each tick as it's simulated (for a demo; "
                         "combine with --interval for a visible pace)")
    ap.add_argument("--interval", type=float, default=0.0,
                    help="seconds to sleep per tick when --live is set")
    args = ap.parse_args()

    run(args.per_class, not args.no_normal, args.split, args.seed,
        args.out, args.live, args.interval)
