#!/usr/bin/env python3
"""
remediation_playbook.py — Zone-based remediation for the UniBonn-Mini dataset.

Design (Option B — 12 fixed playbooks)
--------------------------------------
Remediation depends on two dimensions only:

    * attack ∈ {SYN_Flood, ICMP_Flood, Port_Scan, ARP_Spoofing}
    * zone ∈ {external, internal_standard, critical}

Zone is derived from the sample:

    critical           = victim is in tier3
                         (any attacker; lateral T3 and T2→T3 collapse together)
    external           = attacker is external
                         (only tier1 victims — external cannot reach T2/T3)
    internal_standard  = everything else (internal attacker, non-tier3 victim)

This gives 4 × 3 = 12 (attack, zone) cells. One is physically impossible
(ARP_Spoofing × external, because ARP is layer-2 and confined to a broadcast
domain), so 11 populated cells + one "no action" plan for normal traffic.

Each playbook is a fixed list of steps, each tagged with a phase, using
placeholders like {victim_ip} that get filled from the sample. Same
(attack, zone) → same playbook (up to those substitutions), for every host.

Why not per-host modifiers
--------------------------
An earlier design layered {no_downtime, brief_ok, extended_ok} × {routine,
sensitive, critical} attributes per host, producing 4-8 slightly different
plans per (attack, zone) cell. That was thrown out in favour of zone-only
because you asked for uniform treatment within a zone: a tier3 host is a
tier3 host regardless of whether it is the AD server or the monitoring
server, and the response is critical-zone response either way. If per-host
nuance is wanted later, add a fourth axis; the composer supports it.

Usage
-----
    from remediation_playbook import generate_remediation
    plan = generate_remediation(sample)
    sample["telemetry_details"]["remediation"] = plan["structured"]
    sample["label"]["remediation_text"]        = plan["text"]

    # or, for a whole file:
    python3 remediation_playbook.py train.json train_with_remediation.json
"""

from __future__ import annotations
from typing import Any, Dict, List


# ── Phases (fixed rendering order) ───────────────────────────────────────────

PHASE_ORDER = ["immediate", "contain", "investigate", "must_not",
               "verify", "coordinate"]

PHASE_LABEL = {
    "immediate":   "IMMEDIATE",
    "contain":     "CONTAIN",
    "investigate": "INVESTIGATE",
    "must_not":    "MUST NOT",
    "verify":      "VERIFY",
    "coordinate":  "COORDINATE",
}


def _S(phase: str, template: str) -> Dict[str, str]:
    return {"phase": phase, "template": template}


# ── Zone classification ──────────────────────────────────────────────────────

def zone_of(attacker_tier: str | None, victim_tier: str) -> str:
    """
    Collapse (attacker_tier, victim_tier) into one of:
    critical (tier3 victim), external (external attacker), internal_standard
    (everything else). The user wants uniform treatment within each zone.
    """
    if victim_tier == "tier3":
        return "critical"
    if attacker_tier is None or attacker_tier == "external":
        return "external"
    return "internal_standard"


# ── The 12 playbooks ────────────────────────────────────────────────────────
#
# Keyed by (attack, zone). Templates use {victim_ip}, {attacker_ip},
# {target_port}, {victim_host}, {victim_tier_name}, {open_ports}, and — for
# ARP only — {poisoned_ip}, {rogue_mac}, {expected_mac}.

PLAYBOOK: Dict[tuple, List[Dict[str, str]]] = {

    # ============================================================
    # SYN_Flood
    # ============================================================

    ("SYN_Flood", "external"): [
        _S("immediate",
           "Enable SYN cookies on {victim_ip} if not already active "
           "(net.ipv4.tcp_syncookies=1)."),
        _S("immediate",
           "Add a rate-limit on new TCP connections to {victim_ip}:{target_port} "
           "at the edge firewall — cap at normal peak plus 20%, drop the excess."),
        _S("immediate",
           "Block {attacker_ip}/32 at the edge for 24 hours as a fast bleed "
           "valve. Do not make it permanent; flood sources rotate."),
        _S("contain",
           "Increase the listen backlog on the service on {victim_ip} "
           "(net.ipv4.tcp_max_syn_backlog and the application's own listen "
           "queue) as a stopgap."),
        _S("contain",
           "If traffic is sustained above what your edge can absorb, notify "
           "the upstream ISP or CDN — only they can drop it before it reaches "
           "your edge."),
        _S("investigate",
           "Check {attacker_ip} against threat-intelligence feeds — a known "
           "malicious source changes the response priority."),
        _S("investigate",
           "Determine whether {attacker_ip} is a single source or one of a "
           "botnet by reviewing edge logs for the same pattern against other "
           "public services in the last 24 hours."),
        _S("must_not",
           "Do not broadly block port {target_port} at the firewall — that "
           "takes the service down yourself, handing the attacker the outage "
           "they wanted."),
        _S("must_not",
           "Do not take {victim_ip} offline. This is a public-facing service; "
           "the outage IS the attacker's goal."),
        _S("verify",
           "Aged SYN_SENT count on {victim_ip} returns to single digits."),
        _S("verify",
           "The connection log stops reporting dropped SYN attempts "
           "(dropped=0 in [SUMMARY])."),
        _S("verify",
           "Legitimate connection success rate to {victim_ip}:{target_port} "
           "returns to baseline."),
        _S("coordinate",
           "Log the incident. Edge firewall changes at this scope do not "
           "require pre-authorisation."),
        _S("coordinate",
           "Notify the service owner of {victim_host} if the mitigation "
           "causes any observable degradation to external users."),
    ],

    ("SYN_Flood", "internal_standard"): [
        _S("immediate",
           "Enable SYN cookies on {victim_ip} if not already active "
           "(net.ipv4.tcp_syncookies=1)."),
        _S("immediate",
           "Contain {attacker_ip} at the source — shut its access-switch port "
           "or move it to a quarantine VLAN. This stops the flood immediately "
           "without touching {victim_ip}."),
        _S("contain",
           "Add a temporary rate-limit on new TCP to {victim_ip}:{target_port} "
           "at the tier gateway as a stopgap until source containment is "
           "confirmed."),
        _S("investigate",
           "Before rebooting or wiping {attacker_ip}, capture a memory image "
           "and a process/network snapshot — this is either a compromised host "
           "or a broken script, and you need to know which."),
        _S("investigate",
           "Notify the user or owner of {attacker_ip} out-of-band (phone, not "
           "email). Do not disclose the reason until initial triage completes."),
        _S("investigate",
           "Check other hosts in the attacker's tier for the same outbound "
           "pattern — a compromised workstation is often not the only one."),
        _S("investigate",
           "Audit authentication logs on {victim_ip} for the last 24 hours "
           "from {attacker_ip}. Any successful authentication is a "
           "credential-compromise concern, not just an attack-traffic concern."),
        _S("must_not",
           "Do not address this only at the tier gateway. Rate-limiting the "
           "boundary papers over the internal compromise that is the real "
           "incident."),
        _S("must_not",
           "Do not broadly block port {target_port} — legitimate internal "
           "traffic depends on it."),
        _S("verify",
           "Aged SYN_SENT count on {victim_ip} returns to single digits."),
        _S("verify",
           "The connection log stops reporting dropped SYN attempts "
           "(dropped=0 in [SUMMARY])."),
        _S("verify",
           "No new SYN flood traffic from {attacker_ip} or adjacent hosts in "
           "the attacker's tier appears within the following hour."),
        _S("coordinate",
           "Open a standard change ticket describing both the containment "
           "action and the compromise investigation."),
        _S("coordinate",
           "Treat as an internal-compromise incident, not a network event. "
           "Engage the security team, not just network operations."),
        _S("coordinate",
           "Notify the service owner of {victim_host} before applying "
           "changes that affect availability."),
    ],

    ("SYN_Flood", "critical"): [
        _S("immediate",
           "Enable SYN cookies on {victim_ip} if not already active — this is "
           "the only immediate action on {victim_host} itself that does not "
           "require change-control."),
        _S("immediate",
           "Isolate {attacker_ip} at its access-switch port. Do this "
           "immediately regardless of whether the attacker is in tier2 or "
           "another tier3 host — a tier3 host generating attack traffic is "
           "itself a MAJOR incident."),
        _S("contain",
           "Apply a change-control-approved rate-limit on new TCP to "
           "{victim_ip}:{target_port} at the nearest enforcement point to "
           "{attacker_ip}. Coordinate with change-control before touching "
           "anything on {victim_ip} directly."),
        _S("contain",
           "Take a forensic image of {attacker_ip} before it is rebooted or "
           "reimaged — chain of custody matters here, this is now an "
           "investigation."),
        _S("investigate",
           "Audit ALL authentication and data access on {victim_ip} from "
           "{attacker_ip} in the last 30 days, not 24 hours. If {victim_host} "
           "is an authentication or storage service, treat every successful "
           "auth as a credential-compromise indicator."),
        _S("investigate",
           "Determine what {attacker_ip} normally has legitimate reason to do "
           "against {victim_ip}. Legitimate traffic patterns are the baseline "
           "against which the compromise is measured."),
        _S("investigate",
           "Check the rest of the critical zone (all tier3 hosts) for the "
           "same source IP or the same pattern — a successful reach into "
           "tier3 rarely stops at one host."),
        _S("must_not",
           "NEVER take {victim_ip} offline without explicit sign-off from "
           "security leadership. Tier3 hosts are shared dependencies; "
           "unilateral action can cause organisation-wide outages that dwarf "
           "the attack itself."),
        _S("must_not",
           "Do not resolve this as a pure network incident. A successful "
           "attack — or even attempted attack — against the critical zone "
           "changes the organisation's threat posture and requires a formal "
           "post-incident review."),
        _S("must_not",
           "Do not broadly block port {target_port} at the tier3 gateway — "
           "you will break legitimate dependent services."),
        _S("verify",
           "Aged SYN_SENT count on {victim_ip} returns to single digits."),
        _S("verify",
           "The connection log stops reporting dropped SYN attempts "
           "(dropped=0 in [SUMMARY])."),
        _S("verify",
           "Perform an integrity check on {victim_host}'s data and service "
           "state after the attack window — hash comparison, configuration "
           "diff, service-specific consistency check."),
        _S("verify",
           "Verify all dependent services relying on {victim_host} are "
           "functioning: authentication, data availability, downstream "
           "consumers across all three tiers."),
        _S("coordinate",
           "MAJOR INCIDENT. Change-control REQUIRED before any technical "
           "action on {victim_ip}."),
        _S("coordinate",
           "Notify the security team lead and the tier3 service owner "
           "IMMEDIATELY, regardless of apparent attack severity."),
        _S("coordinate",
           "If any action against {victim_ip} affects service availability, "
           "coordinate a maintenance window; do not act inline."),
        _S("coordinate",
           "Schedule a formal post-incident review within 5 working days."),
    ],

    # ============================================================
    # ICMP_Flood
    # ============================================================

    ("ICMP_Flood", "external"): [
        _S("immediate",
           "Apply an ICMP rate-limit for traffic to {victim_ip} at the edge "
           "firewall — cap at a few hundred pps, drop the excess."),
        _S("immediate",
           "Block {attacker_ip}/32 for ICMP at the edge for 24 hours."),
        _S("contain",
           "If flood is sustained beyond edge capacity, notify upstream ISP "
           "to drop the traffic before it reaches you."),
        _S("investigate",
           "Check whether the flood targets {victim_ip} specifically or is "
           "sweeping tier1 hosts — the response scope differs."),
        _S("investigate",
           "Check {attacker_ip} against threat-intelligence feeds."),
        _S("must_not",
           "Do not disable ICMP entirely on {victim_ip} or its subnet — "
           "legitimate external monitoring (Pingdom, uptime probes, "
           "traceroute) depends on it."),
        _S("verify",
           "ICMP packet rate to {victim_ip} returns to baseline (a few pps)."),
        _S("verify",
           "Echo-request to echo-reply ratio on {victim_ip} returns to ~1:1."),
        _S("coordinate",
           "Log the incident. No pre-authorisation required for standard "
           "edge-firewall ICMP rate-limits."),
        _S("coordinate",
           "Notify the service owner of {victim_host} only if the mitigation "
           "affects legitimate monitoring."),
    ],

    ("ICMP_Flood", "internal_standard"): [
        _S("immediate",
           "Contain {attacker_ip} at the source — shut its access-switch "
           "port. Do NOT rate-limit ICMP at the gateway as your primary "
           "response; that masks the compromise or misconfiguration that is "
           "the real issue."),
        _S("investigate",
           "Before rebooting {attacker_ip}, capture a process list and "
           "network-connection snapshot. Broken monitoring scripts and "
           "malware produce the same telemetry; only forensics tell them "
           "apart."),
        _S("investigate",
           "Check other hosts in the attacker's tier for the same outbound "
           "ICMP pattern."),
        _S("must_not",
           "Do not disable ICMP internally — legitimate monitoring (Nagios, "
           "Icinga, Prometheus probes) depends on it, and the whole tier "
           "will go blind."),
        _S("verify",
           "ICMP packet rate to {victim_ip} returns to baseline within a "
           "minute of containment."),
        _S("verify",
           "Echo-request to echo-reply ratio on {victim_ip} returns to ~1:1."),
        _S("coordinate",
           "Open a standard change ticket."),
        _S("coordinate",
           "Notify the security team if forensics indicate compromise "
           "rather than misconfiguration."),
    ],

    ("ICMP_Flood", "critical"): [
        _S("immediate",
           "Isolate {attacker_ip} at its access-switch port — a source of "
           "attack traffic against the critical zone must be contained "
           "before anything else."),
        _S("contain",
           "Apply a change-control-approved ICMP rate-limit at the nearest "
           "enforcement point to {attacker_ip}. Do not touch {victim_ip} "
           "or its subnet directly without change-control."),
        _S("contain",
           "Take a forensic image of {attacker_ip} before reboot."),
        _S("investigate",
           "Determine whether the flood is a distraction — check tier3 for "
           "any other concurrent anomalous traffic on any channel."),
        _S("investigate",
           "Audit access history of {attacker_ip} — a tier2 host attacking "
           "tier3 or a tier3 host attacking tier3 both indicate credential "
           "or host compromise."),
        _S("must_not",
           "NEVER disable ICMP on {victim_ip} or the tier3 subnet — critical "
           "monitoring depends on it, and going blind on tier3 during an "
           "active attack is worse than the flood itself."),
        _S("must_not",
           "Do not take {victim_ip} offline without security-leadership "
           "sign-off."),
        _S("verify",
           "ICMP packet rate to {victim_ip} returns to baseline."),
        _S("verify",
           "Echo-request to echo-reply ratio on {victim_ip} returns to ~1:1."),
        _S("verify",
           "Verify all monitoring dependent on {victim_host} is still "
           "functional after the mitigation."),
        _S("coordinate",
           "MAJOR INCIDENT. Change-control REQUIRED for any action on "
           "{victim_ip} or its subnet."),
        _S("coordinate",
           "Notify the security team lead IMMEDIATELY."),
        _S("coordinate",
           "Schedule a post-incident review within 5 working days."),
    ],

    # ============================================================
    # Port_Scan
    # ============================================================

    ("Port_Scan", "external"): [
        _S("immediate",
           "Add {attacker_ip} to the edge blocklist for 24 hours. Do not make "
           "the block permanent — external scan sources rotate constantly and "
           "the ruleset will bloat for no benefit."),
        _S("investigate",
           "Verify {victim_host} ({victim_ip}) is only listening on its "
           "intended ports ({open_ports}). Any unexpected open port surfaced "
           "by this scan is the real finding — the scan just told you what "
           "to close."),
        _S("investigate",
           "Check whether {attacker_ip} has appeared against other tier1 "
           "hosts in the last 24 hours — a multi-target scan is targeted "
           "reconnaissance, a single-target scan is noise."),
        _S("must_not",
           "Do not raise this as a high-severity alert on the first "
           "occurrence from a single external source — that produces alert "
           "fatigue and hides the scans that matter."),
        _S("verify",
           "No further scan traffic from {attacker_ip} appears in the edge "
           "logs within the following hour."),
        _S("coordinate",
           "Log the incident at low severity."),
    ],

    ("Port_Scan", "internal_standard"): [
        _S("immediate",
           "Contain {attacker_ip} at its access-switch port. An internal "
           "port scan is reconnaissance, and the source must be treated as "
           "compromised until proven otherwise."),
        _S("investigate",
           "Verify {victim_host} ({victim_ip}) is only listening on its "
           "intended ports ({open_ports}). Any unexpected open port surfaced "
           "by this scan is the real finding."),
        _S("investigate",
           "Capture a memory image and process/network snapshot of "
           "{attacker_ip} before reboot or reimage."),
        _S("investigate",
           "Check what {attacker_ip} has scanned across the whole network — "
           "internal recon rarely targets one host in isolation."),
        _S("investigate",
           "Audit outbound patterns from other hosts in the attacker's tier "
           "for similar reconnaissance behaviour."),
        _S("must_not",
           "Do not treat this as low-severity because it is a scan. Internal "
           "scans indicate a foothold and are typically a late-stage "
           "reconnaissance activity, not an early one."),
        _S("verify",
           "No further scan traffic from {attacker_ip} or adjacent hosts "
           "appears within the following hour."),
        _S("coordinate",
           "Open a standard change ticket for the containment action."),
        _S("coordinate",
           "Engage the security team — internal reconnaissance is an "
           "incident, not a network event."),
    ],

    ("Port_Scan", "critical"): [
        _S("immediate",
           "Isolate {attacker_ip} IMMEDIATELY at its access-switch port. "
           "Reconnaissance against the critical zone is late-stage attacker "
           "behaviour — assume the attacker already has a foothold and is "
           "mapping their next move."),
        _S("contain",
           "Take a forensic image of {attacker_ip} before any change."),
        _S("investigate",
           "Determine what other tier3 hosts {attacker_ip} has scanned or "
           "connected to in the last 30 days. Reconnaissance patterns "
           "reveal attacker intent."),
        _S("investigate",
           "Audit ALL authentication and data access on tier3 hosts from "
           "{attacker_ip} in the last 30 days. If any successful "
           "authentication appears, treat as credential compromise."),
        _S("investigate",
           "Verify {victim_host} ({victim_ip}) is only listening on its "
           "intended ports ({open_ports}). Confirm every open port is "
           "genuinely expected — no drift, no shadow services."),
        _S("must_not",
           "Do not treat this as a routine scan. A scan of the critical "
           "zone from an internal source is a MAJOR INCIDENT until proven "
           "otherwise."),
        _S("must_not",
           "Do not take {victim_ip} offline without security-leadership "
           "sign-off — the scan itself is not the immediate harm; the "
           "attacker's foothold is."),
        _S("verify",
           "No further scan or reconnaissance traffic from {attacker_ip} "
           "against any tier3 host."),
        _S("verify",
           "Integrity check on {victim_host} — confirm nothing was changed "
           "during the reconnaissance window."),
        _S("coordinate",
           "MAJOR INCIDENT. Notify security team lead IMMEDIATELY."),
        _S("coordinate",
           "Schedule a post-incident review within 5 working days."),
        _S("coordinate",
           "Consider whether the incident meets criteria for external "
           "notification (regulator, law enforcement, affected parties)."),
    ],

    # ============================================================
    # ARP_Spoofing (external is physically impossible — layer 2)
    # ============================================================

    ("ARP_Spoofing", "external"): [
        # Placeholder — this combination never occurs in practice because
        # ARP is confined to the broadcast domain. Kept for completeness.
        _S("must_not",
           "This combination should not occur. ARP spoofing is a layer-2 "
           "attack confined to the local broadcast domain and cannot "
           "originate from outside the subnet. If this alert appears, treat "
           "as a mislabelled sample and re-check the diagnosis."),
    ],

    ("ARP_Spoofing", "internal_standard"): [
        _S("immediate",
           "Push a static ARP entry for {poisoned_ip} onto {victim_ip} "
           "(arp -s {poisoned_ip} {expected_mac}) as an immediate fix while "
           "switch-side controls are put in place."),
        _S("immediate",
           "Locate {attacker_ip} on the access switch by looking up the "
           "rogue MAC {rogue_mac} in the MAC address table "
           "(show mac address-table address {rogue_mac}); shut the port it "
           "is on."),
        _S("contain",
           "Enable Dynamic ARP Inspection (DAI) on the {victim_tier_name} "
           "VLAN, paired with a DHCP snooping binding table or a static ARP "
           "ACL that pins {poisoned_ip} to {expected_mac}. This makes the "
           "attack physically impossible to repeat."),
        _S("investigate",
           "Flush the ARP cache on {victim_ip} (ip -s -s neigh flush all) "
           "so it re-learns the correct binding."),
        _S("investigate",
           "Capture memory and process/network snapshot from {attacker_ip} "
           "before reboot."),
        _S("must_not",
           "Do not reboot {victim_ip} — the attacker never touched it, and "
           "a reboot destroys forensic state you need to check whether "
           "traffic was intercepted during the poisoning window."),
        _S("verify",
           "{victim_ip}'s ARP cache shows {expected_mac} for {poisoned_ip}."),
        _S("verify",
           "The switch stops seeing {rogue_mac} on any port."),
        _S("coordinate",
           "Open a standard change ticket for the DAI configuration."),
        _S("coordinate",
           "Notify the security team — ARP poisoning is a targeted, "
           "hands-on attack, not opportunistic noise."),
    ],

    ("ARP_Spoofing", "critical"): [
        _S("immediate",
           "Push a static ARP entry for {poisoned_ip} onto {victim_ip} "
           "(arp -s {poisoned_ip} {expected_mac}) IMMEDIATELY. ARP poisoning "
           "in the critical zone means an attacker is positioned for "
           "interception of tier3 traffic; every second the wrong binding "
           "is in place is a second of possible data capture."),
        _S("immediate",
           "Locate {attacker_ip} on the access switch by looking up "
           "{rogue_mac} in the MAC address table and shut the port. Do this "
           "before any change-control conversation — active interception in "
           "the critical zone justifies emergency action."),
        _S("contain",
           "Enforce Dynamic ARP Inspection (DAI) on the {victim_tier_name} "
           "VLAN with a static ARP ACL pinning EVERY tier3 host's IP to its "
           "registered MAC. This is a permanent hardening, not a fix."),
        _S("contain",
           "Take a forensic image of {attacker_ip}."),
        _S("investigate",
           "Assume traffic between {victim_ip} and {poisoned_ip} was "
           "intercepted for the duration of the poisoning window. Any "
           "credentials, tokens, or sensitive data that crossed that path "
           "must be considered compromised and rotated."),
        _S("investigate",
           "Audit which other tier3 hosts {attacker_ip} could have reached "
           "on layer 2 — assume the attacker attempted poisoning against "
           "them too."),
        _S("investigate",
           "Determine how {attacker_ip} obtained layer-2 access to the "
           "tier3 broadcast domain. This is a segmentation failure as much "
           "as an attack."),
        _S("must_not",
           "Do not resolve as a network-only incident. ARP poisoning against "
           "the critical zone is a MAJOR INCIDENT with credential-exposure "
           "implications."),
        _S("must_not",
           "Do not reboot {victim_ip} or any other tier3 host during "
           "investigation — forensic state must be preserved."),
        _S("verify",
           "{victim_ip}'s ARP cache shows {expected_mac} for {poisoned_ip}."),
        _S("verify",
           "The switch stops seeing {rogue_mac} on any port."),
        _S("verify",
           "DAI is enforced on the tier3 VLAN and rejects any subsequent "
           "spoofed binding."),
        _S("verify",
           "Any credentials or tokens that traversed the poisoned path have "
           "been rotated."),
        _S("coordinate",
           "MAJOR INCIDENT. Notify security team lead IMMEDIATELY."),
        _S("coordinate",
           "Notify data-protection lead — credential compromise in the "
           "critical zone may trigger regulatory notification obligations."),
        _S("coordinate",
           "Schedule a post-incident review within 5 working days, focused "
           "on how tier3 layer-2 access was obtained."),
    ],
}


# Normal-traffic case (no attack)
NORMAL_PLAN = ("No remediation required. Telemetry across all three channels "
               "is at baseline; continue routine monitoring.")


# ── Placeholder substitution ────────────────────────────────────────────────

TIER_HUMAN = {"tier1": "Public", "tier2": "Institutional", "tier3": "Critical"}


def _build_context(sample: Dict[str, Any]) -> Dict[str, Any]:
    label = sample["label"]
    td = sample["telemetry_details"]

    victim_host = td["victim_host"]
    victim_tier = label["victim_tier"]
    attacker_tier = label.get("attacker_tier") or "external"

    ctx: Dict[str, Any] = {
        "attacker_ip":       label.get("attacker_ip") or "N/A",
        "attacker_tier":     attacker_tier,
        "victim_ip":         label["victim_ip"],
        "victim_host":       victim_host,
        "victim_tier":       victim_tier,
        "victim_tier_name":  TIER_HUMAN[victim_tier],
        "target_port":       td.get("target_port") or "N/A",
        "open_ports":        ", ".join(str(p) for p in td.get("victim_open_ports", [])),
        "poisoned_ip":       "N/A",
        "rogue_mac":         "N/A",
        "expected_mac":      "N/A",
    }

    if label["attack_type"] == "ARP_Spoofing":
        poisoned = td.get("poisoned_ips") or []
        if poisoned:
            ctx["poisoned_ip"] = poisoned[0]
        ctx["rogue_mac"] = td.get("rogue_mac") or "N/A"
        exp = td.get("expected_macs") or {}
        if ctx["poisoned_ip"] in exp:
            ctx["expected_mac"] = exp[ctx["poisoned_ip"]]

    return ctx


# ── Composition ─────────────────────────────────────────────────────────────

def generate_remediation(sample: Dict[str, Any]) -> Dict[str, Any]:
    """
    Return { attack, zone, structured, text }.

    structured  — list of {phase, text}, ordered by PHASE_ORDER
    text        — same content rendered as a human-readable block
    """
    label = sample["label"]
    attack = label["attack_type"]

    if attack == "None":
        return {
            "attack": "None",
            "zone": "none",
            "structured": [],
            "text": NORMAL_PLAN,
        }

    zone = zone_of(label.get("attacker_tier"), label["victim_tier"])
    key = (attack, zone)

    if key not in PLAYBOOK:
        raise KeyError(f"No playbook for {key}")

    ctx = _build_context(sample)
    steps: List[Dict[str, str]] = []
    for s in PLAYBOOK[key]:
        try:
            text = s["template"].format(**ctx)
        except KeyError as e:
            text = s["template"] + f"  [MISSING:{e.args[0]}]"
        steps.append({"phase": s["phase"], "text": text})

    # Order by phase (playbooks are written in phase order but sort defensively)
    steps.sort(key=lambda s: PHASE_ORDER.index(s["phase"]))

    # Render text
    lines: List[str] = []
    for phase in PHASE_ORDER:
        items = [s["text"] for s in steps if s["phase"] == phase]
        if not items:
            continue
        lines.append(f"[{PHASE_LABEL[phase]}]")
        for item in items:
            lines.append(f"  - {item}")
        lines.append("")

    return {
        "attack": attack,
        "zone": zone,
        "structured": steps,
        "text": "\n".join(lines).rstrip(),
    }


# ── Injection into a dataset file ────────────────────────────────────────────

def inject_into_dataset(in_path: str, out_path: str) -> None:
    import json
    with open(in_path) as f:
        data = json.load(f)

    for sample in data["dataset"]:
        plan = generate_remediation(sample)
        sample["telemetry_details"]["remediation"] = plan["structured"]
        sample["label"]["remediation_text"] = plan["text"]
        sample["label"]["remediation_zone"] = plan["zone"]

    with open(out_path, "w") as f:
        json.dump(data, f, indent=2)


if __name__ == "__main__":
    import sys
    if len(sys.argv) == 3:
        inject_into_dataset(sys.argv[1], sys.argv[2])
        print(f"Wrote {sys.argv[2]} with remediation injected.")
    else:
        # Print the case table when run without arguments.
        print("(attack, zone) coverage:")
        for k in PLAYBOOK:
            print(f"  {k[0]:15} × {k[1]:20} → {len(PLAYBOOK[k])} steps")
        print()
        print("Usage: python3 remediation_playbook.py IN.json OUT.json")
