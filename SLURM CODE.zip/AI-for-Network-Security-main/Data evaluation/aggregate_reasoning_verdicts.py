#!/usr/bin/env python3
"""
Aggregate the per-instance reasoning verdicts in evaluation_results_detailed.json.

The file holds one record per sample; each record carries stored boolean verdicts
for both models under record['evaluation'][model], with three fields:
    matches_ground_truth
    correctly_explains_identified_attack_presence
    correctly_explains_other_attacks_absence

This script counts those booleans per attack type and overall, for each model.
It only tallies verdicts already in the file; it does not re-score anything.
"""
import json, argparse
from collections import defaultdict

ATTACKS = ['SYN_Flood', 'ICMP_Flood', 'Port_Scan', 'ARP_Spoofing', 'None']
MODELS  = ['baseline', 'finetuned']
FIELDS  = [
    ('matches_ground_truth',                          'Matches GT'),
    ('correctly_explains_identified_attack_presence', 'Attack presence'),
    ('correctly_explains_other_attacks_absence',      'Others absence'),
]

def aggregate(path):
    # counts[model][field][attack] = [n_true, n_total]
    counts = {m: {f: defaultdict(lambda: [0, 0]) for f, _ in FIELDS} for m in MODELS}
    for rec in json.load(open(path)):
        atk = rec['attack_type_ground_truth']
        for m in MODELS:
            ev = rec['evaluation'][m]
            for f, _ in FIELDS:
                counts[m][f][atk][1] += 1
                if ev[f]:
                    counts[m][f][atk][0] += 1
    return counts

def pct(n, d):
    return f"{n}/{d} ({100*n/d:.1f}%)" if d else "-"

def report(counts):
    for f, label in FIELDS:
        print(f"\n### {label} ###")
        hdr = f"{'Attack':<15}{'Baseline':<22}{'Fine-tuned':<22}"
        print(hdr); print('-' * len(hdr))
        tot = {m: [0, 0] for m in MODELS}
        for a in ATTACKS:
            b = counts['baseline'][f][a]
            ft = counts['finetuned'][f][a]
            if b[1] == 0 and ft[1] == 0:
                continue
            for m, c in (('baseline', b), ('finetuned', ft)):
                tot[m][0] += c[0]; tot[m][1] += c[1]
            print(f"{a:<15}{pct(*b):<22}{pct(*ft):<22}")
        print('-' * len(hdr))
        print(f"{'OVERALL':<15}{pct(*tot['baseline']):<22}{pct(*tot['finetuned']):<22}")

if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('detailed_json',
                    help='path to evaluation_results_detailed.json')
    args = ap.parse_args()
    report(aggregate(args.detailed_json))
