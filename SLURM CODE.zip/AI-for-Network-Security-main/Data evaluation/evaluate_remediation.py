#!/usr/bin/env python3
"""
Remediation agreement evaluation.

Compares each generated remediation plan against its own reference playbook cell
(the filled-in ground-truth remediation for the same sample), over the samples
where the attack was correctly identified.

Metrics
-------
token_f1  : unigram overlap F1 (on-topic / vocabulary agreement; order-insensitive)
rouge_l   : longest-common-subsequence F1 (credits preserved action ordering)
action_recall(th) : fraction of reference bullet-actions recovered by some
            generated bullet at token-F1 >= th (0.3 loose, 0.5 close)

All metrics are mechanical; no LLM judge is involved.
"""
import json, re, argparse
from collections import Counter, defaultdict

ATTACKS = ['SYN_Flood', 'ICMP_Flood', 'Port_Scan', 'ARP_Spoofing']

# ---------- text normalisation ----------
def norm(t: str) -> str:
    t = t.lower()
    t = re.sub(r'\[[a-z\-]+\s*\(nist[^\]]*\)\]', ' ', t)  # drop [PHASE (NIST ...)] tags
    t = re.sub(r'[`*]', ' ', t)                            # drop markdown emphasis/code ticks
    return re.sub(r'\s+', ' ', t).strip()

def toks(t: str):
    return re.findall(r'[a-z0-9][a-z0-9\.\-/]*', t)

# ---------- metrics ----------
def token_f1(a: str, b: str) -> float:
    ca, cb = Counter(toks(a)), Counter(toks(b))
    inter = sum((ca & cb).values())
    if inter == 0:
        return 0.0
    p = inter / sum(ca.values())
    r = inter / sum(cb.values())
    return 2 * p * r / (p + r)

def _lcs_len(x, y) -> int:
    m, n = len(x), len(y)
    if m == 0 or n == 0:
        return 0
    dp = [0] * (n + 1)
    for i in range(1, m + 1):
        prev = 0
        for j in range(1, n + 1):
            tmp = dp[j]
            dp[j] = prev + 1 if x[i - 1] == y[j - 1] else max(dp[j], dp[j - 1])
            prev = tmp
    return dp[n]

def rouge_l(a: str, b: str) -> float:
    ta, tb = toks(a), toks(b)
    if not ta or not tb:
        return 0.0
    l = _lcs_len(ta, tb)
    p, r = l / len(ta), l / len(tb)
    return 0.0 if p + r == 0 else 2 * p * r / (p + r)

def actions(t: str):
    """Split a plan into bullet-level actions (>15 chars after normalisation)."""
    out = []
    for line in re.split(r'\n\s*-\s+|\n\s*•\s+', t):
        line = norm(line)
        if len(line) > 15:
            out.append(line)
    return out

def action_recall(gen: str, ref: str, th: float):
    ga, ra = actions(gen), actions(ref)
    if not ra:
        return None  # reference has no parseable actions
    hit = sum(1 for r in ra if max((token_f1(r, g) for g in ga), default=0.0) >= th)
    return hit / len(ra)

# ---------- driver ----------
def evaluate(path, require_correct=True, min_len=20):
    data = json.load(open(path))
    rows = defaultdict(lambda: {'n': 0, 'f1': 0.0, 'rl': 0.0, 'a3': 0.0, 'a5': 0.0})
    for rec in data['records']:
        gt = rec['ground_truth']['attack_type']
        if gt == 'None':
            continue
        if require_correct and rec['parsed']['attack_type'] != gt:
            continue
        ref = rec['ground_truth']['remediation']
        gen = rec['parsed']['remediation']
        a, b = norm(gen), norm(ref)
        d = rows[gt]
        d['n'] += 1
        d['f1'] += token_f1(a, b)
        d['rl'] += rouge_l(a, b)
        d['a3'] += (action_recall(gen, ref, 0.3) or 0.0)
        d['a5'] += (action_recall(gen, ref, 0.5) or 0.0)
    return rows

def report(rows):
    hdr = f"{'Attack':<15}{'N':<5}{'TokenF1':<10}{'ROUGE-L':<10}{'ActRec@.3':<12}{'ActRec@.5':<12}"
    print(hdr); print('-' * len(hdr))
    T = defaultdict(float); N = 0
    for a in ATTACKS:
        d = rows[a]
        if d['n'] == 0:
            continue
        N += d['n']
        for k in ('f1', 'rl', 'a3', 'a5'):
            T[k] += d[k]
        print(f"{a:<15}{d['n']:<5}{100*d['f1']/d['n']:<10.1f}{100*d['rl']/d['n']:<10.1f}"
              f"{100*d['a3']/d['n']:<12.1f}{100*d['a5']/d['n']:<12.1f}")
    if N:
        print('-' * len(hdr))
        print(f"{'OVERALL':<15}{N:<5}{100*T['f1']/N:<10.1f}{100*T['rl']/N:<10.1f}"
              f"{100*T['a3']/N:<12.1f}{100*T['a5']/N:<12.1f}")

if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('results_json', help='path to results_finetuned_full.json')
    ap.add_argument('--all-attacks', action='store_true',
                    help='score all attack samples, not only correctly-detected ones')
    args = ap.parse_args()
    report(evaluate(args.results_json, require_correct=not args.all_attacks))
