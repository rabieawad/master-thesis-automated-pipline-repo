// Download every package from jsdelivr-top.json WITH all of its dependencies.
// No bundling. Each package gets its own folder with a real node_modules tree:
//
//   packages/<name>/package.json
//   packages/<name>/node_modules/<name>/...        <- the package itself
//   packages/<name>/node_modules/<its deps>/...    <- all transitive dependencies
//
// Usage:
//   node download-with-deps.mjs [list.json=jsdelivr-top.json] [outDir=packages] [concurrency=4] [limit=all]
// Examples:
//   node download-with-deps.mjs
//   node download-with-deps.mjs jsdelivr-top.json packages 6 1050   # only the top 1050
//
// Uses pnpm if it is installed (one shared store, hard-linked into every folder = far less
// disk space), otherwise falls back to npm. Force one with: PM=npm node ... or PM=pnpm node ...
// Install pnpm with:  npm i -g pnpm   (or: corepack enable)
//
// Requires Node 18+. Safe to stop and re-run: finished packages are skipped,
// failed ones are retried. Install scripts are NOT run (--ignore-scripts).

import { readFileSync, writeFileSync, mkdirSync, existsSync, rmSync } from "node:fs";
import { execFile, execFileSync } from "node:child_process";
import { promisify } from "node:util";
import { join, resolve } from "node:path";

const run = promisify(execFile);
const isWin = process.platform === "win32";

function hasPnpm() {
  try {
    execFileSync(isWin ? "pnpm.cmd" : "pnpm", ["--version"], { stdio: "ignore", shell: isWin });
    return true;
  } catch {
    return false;
  }
}
const PM = process.env.PM ?? (hasPnpm() ? "pnpm" : "npm");
if (PM !== "npm" && PM !== "pnpm") throw new Error("PM must be npm or pnpm");
const pmBin = isWin ? `${PM}.cmd` : PM;
console.log(`Package manager: ${PM}`);

const listPath = process.argv[2] ?? "jsdelivr-top.json";
const outDir = resolve(process.argv[3] ?? "packages");
const CONC = Number(process.argv[4] ?? 4);
const LIMIT = process.argv[5] && process.argv[5] !== "all" ? Number(process.argv[5]) : Infinity;

const pkgs = JSON.parse(readFileSync(listPath, "utf8")).slice(0, LIMIT);
mkdirSync(outDir, { recursive: true });

// pnpm store lives inside outDir so it is on the same disk -> hard links work (no duplicate copies)
const storeDir = join(outDir, ".pnpm-store");

const folderName = (n) => n.replace(/^@/, "").replace("/", "__");
const DONE = ".download-ok"; // marker file written after a successful install

// By DEFAULT every package is downloaded, including packages with zero dependencies.
// To restrict to packages that declare at least one runtime dependency, set
// ONLY_WITH_DEPS=1 (the npm registry is then asked first, a few KB per package, so
// zero-dependency packages are never installed).
// Note: this looks at the declared "dependencies" of the latest version. What really ends
// up in the bundle is still counted later by bundle-and-sbom.mjs.
const ONLY_WITH_DEPS = process.env.ONLY_WITH_DEPS === "1";
// SKIP_MISSING_DEPS=1 (off by default = faithful): when pnpm stops because a dependency does not
// exist on npm ("… is not in the npm registry" / 404, or "No matching version found" for the
// version asked for), install again without it, using pnpm's
// own `overrides` with "-" (= remove this dependency). The removed names are recorded
// (missingDepsRemoved) so these packages can be reported separately. pnpm only.
const SKIP_MISSING = process.env.SKIP_MISSING_DEPS === "1";
// the dependency pnpm could not find, from its error output
function missingDependency(text) {
  const a = text.match(/(\S+) is not in the npm registry/);
  if (a) return a[1];
  const v = text.match(/No matching version found for (@?[^@\s]+)@\S+/); // the name exists, but not the version asked for
  if (v) return v[1];
  const b = text.match(/ERR_PNPM_FETCH_404\s+GET\s+(\S+?):?\s+Not Found/);
  if (b) { try { return decodeURIComponent(new URL(b[1]).pathname.slice(1)); } catch {} }
  return null;
}
const depCachePath = join(outDir, "dependency-check.json"); // name -> number of declared dependencies
let depCache = {};
try {
  depCache = JSON.parse(readFileSync(depCachePath, "utf8"));
} catch {}

async function declaredDependencyCount(name) {
  if (name in depCache) return depCache[name];
  for (let attempt = 1; attempt <= 3; attempt++) {
    try {
      const res = await fetch(`https://registry.npmjs.org/${name.replace("/", "%2F")}/latest`, { headers: { Accept: "application/json" } });
      if (!res.ok) throw new Error(`registry answered ${res.status}`);
      const count = Object.keys((await res.json()).dependencies ?? {}).length;
      depCache[name] = count;
      writeFileSync(depCachePath, JSON.stringify(depCache, null, 2));
      return count;
    } catch {
      await new Promise((r) => setTimeout(r, 2000 * attempt));
    }
  }
  return null; // could not check: download it anyway rather than silently dropping it
}

async function download({ rank, name }) {
  const folder = folderName(name);
  const dir = join(outDir, folder);
  const tgz = join(outDir, `${folder}.tgz`);
  if (existsSync(tgz)) return { rank, name, ok: true, skipped: true };

  if (ONLY_WITH_DEPS) {
    const deps = await declaredDependencyCount(name);
    if (deps === 0) return { rank, name, ok: true, noDependencies: true };
  }

  const removed = []; // dependencies left out because they do not exist on npm (SKIP_MISSING_DEPS)
  for (let attempt = 1; attempt <= 3; attempt++) {
    try {
      rmSync(dir, { recursive: true, force: true }); // clean partial install
      mkdirSync(dir, { recursive: true });
      writeFileSync(join(dir, "package.json"), JSON.stringify({ name: "holder", version: "1.0.0", private: true,
        ...(removed.length ? { pnpm: { overrides: Object.fromEntries(removed.map((d) => [d, "-"])) } } : {}) }));
      const args =
        PM === "pnpm"
          // --no-optional / --omit=optional: faithful to generate_bundles.py, which installed
          // with `pnpm install --save-exact --no-optional --ignore-scripts`
          // (--loglevel=error instead of a silent reporter: same install, but pnpm's reason is kept when it fails)
          ? ["add", name, "--ignore-scripts", "--no-optional", "--store-dir", storeDir, "--config.auto-install-peers=true", "--loglevel=error"]
          : ["install", name, "--ignore-scripts", "--omit=optional", "--no-audit", "--no-fund", "--legacy-peer-deps", "--prefer-offline", "--loglevel=error"];
      // Never let git/ssh stop and ask a question (e.g. a dependency pointing at a private
      // GitHub repo): with these settings it fails right away and the package is marked FAIL.
      const env = { ...process.env, GIT_TERMINAL_PROMPT: "0", GIT_SSH_COMMAND: "ssh -o BatchMode=yes" };
      await run(pmBin, args, { cwd: dir, env, timeout: 5 * 60_000, maxBuffer: 20 * 1024 * 1024, shell: isWin });
      const version = JSON.parse(readFileSync(join(dir, "node_modules", ...name.split("/"), "package.json"), "utf8")).version;
      // "always tar the download": collapse the whole install tree (holder package.json +
      // node_modules) into ONE .tgz, and keep a tiny meta sidecar so the bundler can learn
      // name/version without extracting. Then remove the tree of many small files.
      writeFileSync(join(outDir, `${folder}.meta.json`), JSON.stringify({ name, version, ...(removed.length ? { missingDepsRemoved: removed } : {}) }));
      await run("tar", ["-czf", tgz, "-C", dir, "."], { timeout: 5 * 60_000, maxBuffer: 20 * 1024 * 1024, shell: isWin });
      rmSync(dir, { recursive: true, force: true });
      return { rank, name, ok: true, version, ...(removed.length ? { missingDepsRemoved: removed } : {}) };
    } catch (e) {
      const text = `${e.stdout ?? ""}\n${e.stderr ?? ""}`;
      const missing = SKIP_MISSING && PM === "pnpm" ? missingDependency(text) : null;
      if (missing && missing !== name && !removed.includes(missing) && removed.length < 100) {
        removed.push(missing);
        console.log(`  ${name}: dependency ${missing} does not exist on npm — installing without it`);
        attempt--; // not a failed attempt: try again without that dependency
        continue;
      }
      // the error as pnpm/npm gave it (e.g. "ERR_PNPM_FETCH_404 … core-x is not in the npm registry")
      const reason = text.split("\n").map((l) => l.trim()).filter((l) => /ERR_|not in the npm registry|No matching version|error|Forbidden|Not Found/i.test(l)).slice(0, 2).join(" ");
      if (attempt === 3)
        return { rank, name, ok: false, error: (reason || String(e.stderr || e.message).split("\n").filter(Boolean).slice(0, 2).join(" ")).slice(0, 300) };
      await new Promise((r) => setTimeout(r, 3000 * attempt));
    }
  }
}

const results = [];
let next = 0;
const started = Date.now();

await Promise.all(
  Array.from({ length: CONC }, async () => {
    while (next < pkgs.length) {
      const r = await download(pkgs[next++]);
      results.push(r);
      const mins = ((Date.now() - started) / 60000).toFixed(1);
      const tag = !r.ok ? "FAIL" : r.noDependencies ? "none" : r.skipped ? "skip" : "ok  ";
      console.log(`[${results.length}/${pkgs.length}] ${tag} ${r.name}${r.ok ? (r.noDependencies ? "  (no dependencies, not downloaded)" : "") : "  -> " + r.error}  (${mins} min)`);
    }
  })
);

results.sort((a, b) => a.rank - b.rank);
writeFileSync(join(outDir, "download-results.json"), JSON.stringify(results, null, 2));
const failed = results.filter((r) => !r.ok);
const noDeps = results.filter((r) => r.noDependencies).length;
console.log(`\nDone. downloaded/skipped=${results.length - failed.length - noDeps}  no-dependencies=${noDeps}  failed=${failed.length}`);
if (failed.length) console.log("Failed packages are listed in download-results.json - just re-run the script to retry them.");
