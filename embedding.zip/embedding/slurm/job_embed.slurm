#!/bin/bash
# ============================================================================
# SLURM job: embed every function of a .tgz (or folder) of *.functions.json files with one model.
#
# SUBMIT FROM THE embedding/ FOLDER:
#   sbatch slurm/job_embed.slurm /path/to/functions.tgz jina-code-0.5b
#   sbatch slurm/job_embed.slurm /path/to/functions.tgz jina-code-0.5b --sample 0.01   # timing test first
# Anything after the model name is passed to embed.py (see: python embed.py --help).
#
# Results: $OUT_ROOT/<model>/  (default ~/embeddings/<model>/), one .npz per input file + manifest.json.
# If the job hits its time limit, submit the same command again: finished work is reused.
# MONITOR:  squeue --me    and    tail -f embed_<jobid>.log
# ============================================================================
#SBATCH --job-name=embed
#SBATCH --partition=sgpu_long
#SBATCH --account=ag_ifi_martini
#SBATCH --gpus=1
#SBATCH --cpus-per-task=8
#SBATCH --mem=64G
#SBATCH --time=08:00:00
#SBATCH --output=embed_%j.log
#SBATCH --error=embed_%j.log

set -euo pipefail
export SLURM_EXPORT_ENV=ALL

INPUT="${1:?Usage: sbatch slurm/job_embed.slurm <input.tgz|folder> <model> [embed.py options]}"
MODEL="${2:?Usage: sbatch slurm/job_embed.slurm <input.tgz|folder> <model> [embed.py options]}"
shift 2

# Where the code is: the folder you submitted from (embedding/), or its parent if you submitted from slurm/
CODE_DIR="${CODE_DIR:-$SLURM_SUBMIT_DIR}"
[[ -f "$CODE_DIR/embed.py" ]] || CODE_DIR="$(dirname "$CODE_DIR")"
OUT_ROOT="${OUT_ROOT:-$HOME/embeddings}"
ENV_DIR="${ENV_DIR:-$HOME/envs/embed}"
WORK_DIR="${TMPDIR:-/tmp}/embed_$SLURM_JOB_ID"   # node-local: the archive is extracted here

echo "Job $SLURM_JOB_ID on $(hostname) at $(date)"
echo ">>> input=$INPUT  model=$MODEL  out=$OUT_ROOT/$MODEL  extra args: $*"

module load Miniforge3
ENV_PY="$ENV_DIR/bin/python"
source activate "$ENV_DIR"

export HF_HUB_DISABLE_XET=1
export HF_HOME="${HF_HOME_DIR:-${TMPDIR:-/tmp}/hf_cache_$SLURM_JOB_ID}"   # set HF_HOME_DIR to keep downloads
export TOKENIZERS_PARALLELISM=true
mkdir -p "$HF_HOME" "$WORK_DIR" "$OUT_ROOT"

echo ">>> Preflight checks"
test -x "$ENV_PY"              || { echo "ERROR: env Python not found at $ENV_PY (run setup_env.sh once)"; exit 1; }
test -f "$CODE_DIR/embed.py"   || { echo "ERROR: embed.py not found in $CODE_DIR; submit from the embedding/ folder"; exit 1; }
test -e "$INPUT"               || { echo "ERROR: input not found: $INPUT"; exit 1; }
"$ENV_PY" -c "import torch, transformers, numpy; assert torch.cuda.is_available(), 'no GPU visible'; print('torch', torch.__version__, 'transformers', transformers.__version__, 'gpu', torch.cuda.get_device_name(0))" \
    || { echo "ERROR: environment or GPU check failed"; exit 1; }
echo ">>> Preflight OK"
nvidia-smi

"$ENV_PY" "$CODE_DIR/embed.py" --input "$INPUT" --model "$MODEL" --out "$OUT_ROOT" --workdir "$WORK_DIR" "$@"

rm -rf "$WORK_DIR"
echo "Job $SLURM_JOB_ID finished at $(date)"
