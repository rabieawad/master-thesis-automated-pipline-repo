# Function embeddings

Embeds every function of the step-06 `*.functions.json` files (old v1 and new v2 format) and writes one
`.npz` per input file, named after it, with each vector tied to its function `index`.

## Layout

| Path | Part | What it does |
| --- | --- | --- |
| `embed.py` | shared | command line; ties everything together |
| `common/archive.py` | shared | safe .tgz extraction into `$TMPDIR`, finds `*.functions.json` |
| `common/records.py` | shared | reads files, picks the text (`textNorm` > `text` > `rawText`), dedups identical texts |
| `common/engine.py` | shared | token counting, chunking of long functions, length-sorted batches, OOM retry, progress |
| `common/cache.py` | shared | vectors of unique texts saved in parts: resume after a timeout, reuse for new packages |
| `common/writer.py` | shared | one output `.npz` per input file |
| `models/base.py` | interface | what every model adapter must implement |
| `models/hf_base.py` | shared for HF models | tokenizer, prefix, pooling, dtype, attention backend |
| `models/jina_code.py` | model-specific | jina-code-embeddings-0.5b: 896 dims, 32k tokens, last-token pooling, prompt |
| `models/__init__.py` | registry | short model name -> adapter |
| `slurm/job_embed.slurm` | cluster | Marvin job (ag_ifi_martini, sgpu_long, 1 A100) |
| `slurm/setup_env.sh` | cluster | creates `~/envs/embed` once |
| `check_outputs.py` | shared | verifies a finished run |

A new model = one adapter file in `models/` + one line in `models/__init__.py`. Output goes to
`<out>/<model name>/`, so models never overwrite each other.

## On Marvin

```bash
cd embedding
bash slurm/setup_env.sh                                                   # once, on a login node
sbatch slurm/job_embed.slurm ~/data/functions.tgz jina-code-0.5b --sample 0.01   # timing test
sbatch slurm/job_embed.slurm ~/data/functions.tgz jina-code-0.5b                 # full run
python check_outputs.py $TMPDIR/... ~/embeddings/jina-code-0.5b           # optional check
```

If a job times out, submit it again: embedded texts are kept in `_cache/` and finished files are skipped.
When new packages are added, run on the new archive with the same `--out`: only texts never seen before
are embedded.

## Output file

`<name>@<version>.functions.<model>.npz`, read with `np.load(path)`:

- `index` (int32): the function's `index` in the input file; row i belongs to `index[i]`
- `embedding` (float16, n x 896): L2-normalised vector
- `key` (str): `n:`+hashNorm, `t:`+hash, or `s:`+sha256 of the text, to join with the JSON
- `n_tokens` (int32): tokens of the function text
- `n_chunks` (int16): 1 = embedded whole; more = longer than the window, mean of overlapping chunks

Functions without any text are left out (counted in `manifest.json`); empty or broken input files are
listed there under `files_skipped`.
