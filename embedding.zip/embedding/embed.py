"""Embed every function of a set of *.functions.json files (step 06 output) with one model.

  python embed.py --input functions.tgz --model jina-code-0.5b --out ~/embeddings
  python embed.py --input functions.tgz --model jina-code-0.5b --sample 0.01      # timing test only

Input: a .tgz/.tar.gz/.tar archive, a folder, or one .functions.json file.
Output, in <out>/<model>/:
  <name>@<version>.functions.<model>.npz   one per input file; arrays index, embedding, key, n_tokens, n_chunks
  _cache/part-*.npz                        vectors of unique texts; lets a stopped job resume and lets later
                                           runs (new packages) embed only texts not seen before
  manifest.json                            settings, counts, skipped files and timings of the last run
Every unique function text is embedded once, however many files and versions contain it.
"""
from __future__ import annotations

import argparse
import json
import logging
import os
import platform
import random
import socket
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from common.archive import default_workdir, resolve_input  # noqa: E402
from common.cache import VectorCache  # noqa: E402
from common.engine import EngineConfig, count_tokens, embed_unique  # noqa: E402
from common.records import TEXT_FIELDS, load_corpus  # noqa: E402
from common.writer import output_path, write_file  # noqa: E402
from models import MODELS, get_model  # noqa: E402

log = logging.getLogger("embed")


def parse_args(argv=None):
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--input", required=True, type=Path, help=".tgz / folder / .functions.json")
    p.add_argument("--model", required=True, choices=sorted(MODELS))
    p.add_argument("--out", type=Path, default=Path("embeddings"), help="output root; results go to <out>/<model>/")
    p.add_argument("--workdir", type=Path, default=None, help="where archives are extracted (default $TMPDIR)")
    p.add_argument("--model-path", default=None, help="local model folder instead of downloading from Hugging Face")
    p.add_argument("--text-field", default="auto", choices=sorted(TEXT_FIELDS),
                   help="auto = textNorm, else text, else rawText")
    p.add_argument("--window", type=int, default=32768, help="max tokens per function before it is chunked")
    p.add_argument("--overlap", type=int, default=256, help="token overlap between chunks")
    p.add_argument("--token-budget", type=int, default=131072, help="max padded tokens per batch")
    p.add_argument("--max-batch", type=int, default=256)
    p.add_argument("--device", default="auto")
    p.add_argument("--dtype", default="bfloat16", choices=["bfloat16", "float16", "float32"])
    p.add_argument("--attn", default="auto", help="auto | flash_attention_2 | sdpa | eager")
    p.add_argument("--sample", type=float, default=None,
                   help="embed only this fraction of unique texts, print throughput and projected time, write no outputs")
    p.add_argument("--seed", type=int, default=0)
    p.add_argument("--limit-files", type=int, default=None, help="only the first N files (testing)")
    p.add_argument("--overwrite", action="store_true", help="rewrite output files that already exist")
    return p.parse_args(argv)


def main(argv=None):
    args = parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s",
                        datefmt="%H:%M:%S")
    t_start = time.time()
    workdir = args.workdir or default_workdir()

    files = resolve_input(args.input, workdir)
    if args.limit_files:
        files = files[: args.limit_files]
    if not files:
        raise SystemExit(f"no *.functions.json files found in {args.input}")
    corpus = load_corpus(files, args.text_field)

    embedder = get_model(args.model, model_path=args.model_path, device=args.device, dtype=args.dtype, attn=args.attn)
    embedder.load()
    cfg = EngineConfig(window=args.window, overlap=args.overlap, token_budget=args.token_budget,
                       max_batch=args.max_batch)
    out_dir = args.out / embedder.name
    out_dir.mkdir(parents=True, exist_ok=True)

    if args.sample:
        return run_sample(args, corpus, embedder, cfg, out_dir, workdir)

    cache = VectorCache(out_dir / "_cache", embedder.dim)
    todo = {k: t for k, t in corpus.texts.items() if k not in cache}
    log.info("%d unique texts, %d already embedded, %d to embed", len(corpus.texts), len(corpus.texts) - len(todo), len(todo))
    stats = embed_unique(embedder, todo, cache, cfg)

    written = skipped_existing = 0
    for ff in corpus.files:
        path = output_path(ff.path, out_dir, embedder.name)
        if path.exists() and not args.overwrite:
            skipped_existing += 1
            continue
        write_file(ff, cache, path)
        written += 1
    log.info("wrote %d files, %d already existed", written, skipped_existing)

    manifest = {
        "created": time.strftime("%Y-%m-%dT%H:%M:%S"),
        "host": socket.gethostname(), "slurm_job": os.environ.get("SLURM_JOB_ID"),
        "python": platform.python_version(), "versions": _versions(),
        "input": str(args.input), "text_field": args.text_field,
        "model": embedder.describe(), "engine": vars(cfg),
        "files_in": len(files), "files_written": written, "files_already_there": skipped_existing,
        "files_skipped": corpus.bad_files,
        "functions": corpus.total_functions,
        "functions_without_text": sum(f.skipped for f in corpus.files),
        "unique_texts": len(corpus.texts), "embedded_this_run": stats,
        "total_seconds": round(time.time() - t_start, 1),
    }
    (out_dir / "manifest.json").write_text(json.dumps(manifest, indent=1))
    log.info("done in %.1f min; manifest: %s", (time.time() - t_start) / 60, out_dir / "manifest.json")


def run_sample(args, corpus, embedder, cfg, out_dir, workdir):
    """Embed a random fraction into a throw-away cache and project the full run time."""
    keys = sorted(corpus.texts)
    random.Random(args.seed).shuffle(keys)
    n = max(1, int(len(keys) * args.sample))
    sample = {k: corpus.texts[k] for k in keys[:n]}
    log.info("sample mode: %d of %d unique texts; counting tokens of all texts for the projection", n, len(keys))
    all_tokens = int(count_tokens(embedder, [corpus.texts[k] for k in keys]).sum())
    tmp_cache = VectorCache(workdir / f"sample_cache_{embedder.name}_{int(time.time())}", embedder.dim)
    stats = embed_unique(embedder, sample, tmp_cache, cfg)
    tps = stats["tokens_per_s"]
    report = {"sample": stats, "all_unique_texts": len(keys), "all_tokens": all_tokens,
              "projected_minutes": round(all_tokens / max(tps, 1e-9) / 60, 1),
              "projected_output_gb_float16": round(len(keys) * embedder.dim * 2 / 1e9, 2),
              "model": embedder.describe(), "engine": vars(cfg)}
    (out_dir / "sample_report.json").write_text(json.dumps(report, indent=1))
    log.info("SAMPLE: %.0f tokens/s, %.1f functions/s -> about %.1f min for all %d unique texts (%d tokens)",
             tps, stats["functions_per_s"], report["projected_minutes"], len(keys), all_tokens)


def _versions() -> dict:
    out = {}
    for mod in ("torch", "transformers", "numpy", "flash_attn"):
        try:
            out[mod] = __import__(mod).__version__
        except Exception:
            out[mod] = None
    return out


if __name__ == "__main__":
    main()
